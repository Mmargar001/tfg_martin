<?php
// Inicia la sesión
session_start();

// Cierra todas las sesiones existentes
session_unset();  // Elimina todas las variables de sesión
session_destroy();  // Destruye la sesión
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Inicio</title>
        <link rel="stylesheet" type="text/css" href="../src/Estilos/estilosComunes.css">
        <style>
            /* Estilos adicionales para mejorar la visibilidad del enlace "Contáctanos" */
            .footer a {
                color: white; /* Hace el texto blanco */
                text-decoration: none; /* Elimina el subrayado predeterminado */
                font-weight: bold; /* Texto en negrita */
            }

            .footer a:hover {
                color: #FFD700; /* Cambia el color al pasar el ratón (dorado) */
                text-decoration: underline; /* Subrayado al pasar el ratón */
            }

            .footer {
                text-align: center;
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <div class="form-container">
            <h1>Bienvenido a Planify</h1>
            <p>Organiza tus actividades diarias de manera eficiente y sin complicaciones.</p>

            <div class="actions">
                <a href="../src/Vista/registro.php" class="submit-button">Registrarse</a>
                <a href="../src/Vista/login.php" class="submit-button">Iniciar Sesión</a>
            </div>
        </div>

        <div class="footer">
            <p>¿Necesitas ayuda? <a href="../src/Vista/contacto.php">Contáctanos</a></p>
        </div>
    </body>
</html>
