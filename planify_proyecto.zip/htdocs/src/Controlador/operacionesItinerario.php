<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';

use proyecto\Modelo\Itinerarios;  // Usar el espacio de nombres adecuado para Itinerarios
use proyecto\Modelo\Actividades;  // Usar el espacio de nombres adecuado para Actividades
use proyecto\Modelo\Reservas;  // Usar el espacio de nombres adecuado para Reservas

// Verificar que el usuario esté autenticado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../Vista/login.php');
    
}

// Crear un itinerario
if (isset($_POST['crear_itinerario']) && isset($_POST['nombre']) && isset($_POST['descripcion']) && isset($_POST['presupuesto'])) {
    $nombre = trim($_POST['nombre']);
    $descripcion = trim($_POST['descripcion']);
    $presupuesto = floatval($_POST['presupuesto']);
    $usuario = $_SESSION['usuario_id'];

    // Obtener todos los itinerarios del usuario
    $itinerarios = Itinerarios::obtenerItinerariosPorUsuario($usuario);

    // Verificar si ya existe un itinerario con el mismo nombre para el mismo usuario
    $itinerarioExistente = false;
    foreach ($itinerarios as $itinerario) {
        if ($itinerario['nombre'] === $nombre) {
            $itinerarioExistente = true;
            break;
        }
    }

    if ($itinerarioExistente) {
        // Si ya existe un itinerario con el mismo nombre, redirigir con un mensaje de error
        header("Location: ../Vista/crearItinerario.php?error=Ya existe un itinerario con ese nombre.");
        
    }

    // Crear o actualizar el itinerario con el presupuesto
    $resultado = Itinerarios::crearOActualizarItinerario($usuario, $nombre, $descripcion, $presupuesto);

    if ($resultado) {
        header("Location: ../Vista/inicioCliente.php?success=Itinerario creado o actualizado exitosamente.");
    } else {
        header("Location: ../Vista/crearItinerario.php?error=Error al crear o actualizar el itinerario.");
    }
 
}

// Editar nombre de un itinerario
if (isset($_POST['editar_itinerario']) && isset($_POST['itinerario_id']) && isset($_POST['nombre'])) {
    $itinerario_id = intval($_POST['itinerario_id']); // Aquí estaba el problema
    $nuevo_nombre = trim($_POST['nombre']);

    // Verificar si el itinerario existe
    $itinerario = Itinerarios::obtenerItinerarioPorId($itinerario_id); // Corregido

    if ($itinerario) {
        // Actualizar el nombre del itinerario
        $resultado = Itinerarios::actualizarNombreItinerario($itinerario_id, $nuevo_nombre);

        if ($resultado) {
            // Redirigir con mensaje de éxito
            header("Location: ../Vista/gestionItinerarios.php?success=Nombre del itinerario actualizado exitosamente.");
        } else {
            // Redirigir con mensaje de error si algo falla al actualizar
            header("Location: ../Vista/gestionItinerarios.php?error=Error al actualizar el nombre del itinerario.");
        }
    } else {
        // Si el itinerario no existe
        header("Location: ../Vista/gestionItinerarios.php?error=Itinerario no encontrado.");
    }
    
}


// Eliminar un itinerario
if (isset($_POST['eliminar_itinerario']) && isset($_POST['itinerario_id'])) {
    $itinerario_id = intval($_POST['itinerario_id']);

    // Verificar si el usuario es un administrador
    if ($_SESSION['rol'] === 'administrador') {
        // El administrador puede eliminar cualquier itinerario
        $resultado = Itinerarios::eliminarItinerario($itinerario_id);

        // Redirigir al administrador a la gestión de itinerarios
        if ($resultado) {
            header("Location: ../Vista/gestionItinerarios.php?success=Itinerario eliminado exitosamente.");
        } else {
            header("Location: ../Vista/gestionItinerarios.php?error=Error al eliminar itinerario.");
        }
    } else {
        // Si es un cliente, verificar si el itinerario le pertenece
        $usuario_id = $_SESSION['usuario_id'];
        $itinerario = Itinerarios::obtenerItinerarioPorId($itinerario_id);

        if ($itinerario && $itinerario['usuario_id'] == $usuario_id) {
            // El cliente solo puede eliminar sus propios itinerarios
            $resultado = Itinerarios::eliminarItinerario($itinerario_id);

            if ($resultado) {
                header("Location: ../Vista/inicioCliente.php?success=Itinerario eliminado exitosamente.");
            } else {
                header("Location: ../Vista/inicioCliente.php?error=Error al eliminar itinerario.");
            }
        } else {
            // Si el itinerario no pertenece al usuario, redirigir con un mensaje de error
            header("Location: ../Vista/inicioCliente.php?error=No tienes permiso para eliminar este itinerario.");
        }
    }
    
}

// Agregar una actividad a un itinerario
if (isset($_POST['agregar_actividad']) && isset($_POST['itinerario_id']) && isset($_POST['actividad_id'])) {
    $itinerario_id = intval($_POST['itinerario_id']);
    $actividad_id = intval($_POST['actividad_id']);

    // Obtener detalles de la actividad seleccionada
    $actividad = Actividades::obtenerActividadPorId($actividad_id);

    // Verificar solapamiento de actividades
    $actividadesAsociadas = Itinerarios::obtenerActividadesPorItinerario($itinerario_id);
    foreach ($actividadesAsociadas as $asociada) {
        $inicioAsociada = strtotime($asociada['fecha'] . ' ' . $asociada['hora']);
        $finAsociada = $inicioAsociada + ($asociada['duracion'] * 3600);
        $inicioNueva = strtotime($actividad['fecha'] . ' ' . $actividad['hora']);
        $finNueva = $inicioNueva + ($actividad['duracion'] * 3600);

        if (
            ($inicioNueva >= $inicioAsociada && $inicioNueva < $finAsociada) ||
            ($finNueva > $inicioAsociada && $finNueva <= $finAsociada) ||
            ($inicioNueva <= $inicioAsociada && $finNueva >= $finAsociada)
        ) {
            header("Location: ../Vista/gestionClienteItinerarios.php?id=$itinerario_id&error=Conflicto de horarios con otra actividad.");
            
        }
    }

    // Agregar la actividad al itinerario si no hay solapamiento
    $resultado = Itinerarios::agregarActividad($itinerario_id, $actividad_id);

    if ($resultado) {
        header("Location: ../Vista/gestionClienteItinerarios.php?id=$itinerario_id&success=Actividad agregada exitosamente.");
    } else {
        header("Location: ../Vista/gestionClienteItinerarios.php?id=$itinerario_id&error=Error al agregar actividad.");
    }

}

// Eliminar una actividad de un itinerario
if (isset($_POST['eliminar_actividad']) && isset($_POST['itinerario_id']) && isset($_POST['actividad_id'])) {
    $itinerario_id = intval($_POST['itinerario_id']);
    $actividad_id = intval($_POST['actividad_id']);

    $resultado = Itinerarios::eliminarActividad($itinerario_id, $actividad_id);

    if ($resultado) {
        header("Location: ../Vista/gestionClienteItinerarios.php?id=$itinerario_id&success=Actividad eliminada exitosamente.");
    } else {
        header("Location: ../Vista/gestionClienteItinerarios.php?id=$itinerario_id&error=Error al eliminar actividad.");
    }
 
}
?>
