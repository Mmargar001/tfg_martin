<?php 
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Notificaciones;

// Verificar que el usuario esté autenticado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../Vista/login.php');
    exit();
} else {
    error_log("Sesión persistente. Usuario ID: " . $_SESSION['usuario_id']);
}

$usuario = $_SESSION['usuario_id'];
$notificaciones_no_leidas = Notificaciones::contarNoLeidas($usuario);

// Obtener notificaciones 
if (isset($_GET['accion']) && $_GET['accion'] === 'ver_notificaciones') {
    $notificaciones = Notificaciones::obtenerNotificaciones($usuario);
    include '../Vista/notificacionesVista.php'; // Vista para mostrar notificaciones
    exit();
}

// Marcar una notificación como leída
if (isset($_POST['marcar_leida']) && isset($_POST['notificacion_id'])) {
    $notificacion_id = intval($_POST['notificacion_id']);
    
    // Depuración: verifica si se obtuvo correctamente el ID de la notificación
    error_log("Notificación ID a marcar como leída: " . $notificacion_id);
    
    // Marca la notificación como leída
    Notificaciones::marcarComoLeida($usuario);
    
    // Redirigir a la vista de notificaciones
    header('Location: ../Controlador/notificacionesController.php?accion=ver_notificaciones');
exit();
    exit();
}

// Marcar todas las notificaciones como leídas
if (isset($_POST['marcar_todas_leidas'])) {
    
    
    Notificaciones::marcarTodasComoLeidas($usuario);
    
    // Redirigir a la vista de notificaciones
    header('Location: ../Controlador/notificacionesController.php?accion=ver_notificaciones');
    exit();
}


// Crear una nueva notificación (solo para administradores)
if (isset($_POST['crear_notificacion']) && isset($_POST['usuario_id']) && isset($_POST['mensaje'])) {
    // Verificar si el usuario es un administrador
    if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'administrador') {
        $usuario_id_nueva = intval($_POST['usuario_id']);
        $mensaje = trim($_POST['mensaje']);

        if (Notificaciones::agregarNotificacion($usuario_id_nueva, $mensaje)) {
            header('Location: ../Vista/gestionNotificaciones.php?success=Notificación creada con éxito.');
        } else {
            header('Location: ../Vista/gestionNotificaciones.php?error=Error al crear la notificación.');
        }
        exit();
    } else {
        header('Location: ../Vista/login.php');
        exit();
    }
}
// Eliminar una notificación
if (isset($_POST['eliminar_notificacion']) && isset($_POST['notificacion_id'])) {
    $notificacion_id = intval($_POST['notificacion_id']);
    if (Notificaciones::eliminarNotificacion($notificacion_id)) {
        header('Location: ../Vista/gestionNotificaciones.php?success=Notificación eliminada con éxito.');
    } else {
        header('Location: ../Vista/gestionNotificaciones.php?error=Error al eliminar la notificación.');
    }
    exit();
}

// Redirigir al inicio si no se cumplen las condiciones anteriores
header('Location: ../Vista/login.php');
exit();
?>