<?php
session_start();
use proyecto\Modelo\Usuarios;
require_once __DIR__ . '/../../vendor/autoload.php';



$errores = [];

// Si el usuario está logueado se elimina la sesión
if (isset($_SESSION['rol'])) {
    session_destroy();
    session_start(); // Reiniciar la sesión después de destruirla
}

// Limite de intentos y tiempo
$maxIntentos = 3; // Máximo de intentos permitidos
$tiempoBloqueo = 30; // Tiempo de bloqueo en segundos

// Verificar e incrementar intentos fallidos
if (isset($_SESSION['intentos_fallidos'])) {
    $_SESSION['intentos_fallidos']++;
} else {
    $_SESSION['intentos_fallidos'] = 1;
}

// Verificar tiempo de bloqueo restante
if (isset($_SESSION['ultimo_intent_fallido']) && time() - $_SESSION['ultimo_intent_fallido'] <= $tiempoBloqueo) {
    $tiempoRestante = $tiempoBloqueo - (time() - $_SESSION['ultimo_intent_fallido']);
} else {
    $tiempoRestante = 0;
    unset($_SESSION['intentos_fallidos']);
}

// SI SE HA INICIADO SESIÓN
if (filter_has_var(INPUT_POST, 'inicio_sesion')) {
    if (filter_has_var(INPUT_POST, 'usuario') && filter_has_var(INPUT_POST, 'contrasena')) {
        $usuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING);
        $contrasena = filter_input(INPUT_POST, 'contrasena', FILTER_SANITIZE_STRING);

        //si hay usuario y contraseña
        if (!empty($usuario) && !empty($contrasena)) {
            try {
                // Verificar si el usuario está bloqueado
                if (isset($_SESSION['intentos_fallidos']) && $_SESSION['intentos_fallidos'] >= $maxIntentos && $tiempoRestante > 0) {
                    $errores[] = "❌ El usuario está bloqueado debido a múltiples intentos fallidos. Intente de nuevo en " . gmdate("i:s", $tiempoRestante);
                } else {
                    // Obtener el usuario desde la base de datos
                    $usuarioValido = Usuarios::obtenerUsuarioPorNombre($usuario);

                    if ($usuarioValido) {
                        // Verificar contraseña
                        if (password_verify($contrasena, $usuarioValido['clave'])) {
                            // Restablecer intentos fallidos
                            unset($_SESSION['intentos_fallidos']);

                            // Usuario y contraseña válidos
                            $_SESSION['rol'] = $usuarioValido['tipo'];
                            $_SESSION['usuario'] = $usuarioValido['nombre'];
                            $_SESSION['usuario_id'] = $usuarioValido['id'];

                            // Incrementar contador de visitas
                            if (isset($_COOKIE['visitas_' . $usuarioValido['nombre']])) {
                                $numVisitas = $_COOKIE['visitas_' . $usuarioValido['nombre']] + 1;
                            } else {
                                $numVisitas = 1;
                            }
                            setcookie('visitas_' . $usuarioValido['nombre'], $numVisitas, time() + (86400 * 7), "/");

                            // Redirigir según el rol de usuario
                            switch ($_SESSION['rol']) {
                                case 'administrador':
                                    header("Location: ../Vista/inicioAdmin.php");
                                    exit();
                                case 'cliente':
                                    header("Location: ../Vista/inicioCliente.php");
                                    exit();
                                default:
                                    $errores[] = "❌ Rol de usuario no válido.";
                            }
                        } else {
                            // Contraseña incorrecta
                            $errores[] = "❌ Contraseña incorrecta. Por favor, inténtalo de nuevo.";

                            // Actualizar intentos fallidos
                            $_SESSION['ultimo_intent_fallido'] = time();
                        }
                    } else {
                        // Usuario no encontrado
                      $errores[] = "❌ Usuario no encontrado. Por favor, <a href='../Vista/registro.php' class='crear-usuario-link'>registra una cuenta</a>.";

                    }
                }
            } catch (PDOException $e) {
                $errores[] = "❌ Error de conexión con la base de datos: " . $e->getMessage();
            }
        } else {
            $errores[] = "❌ Por favor, proporciona usuario y contraseña.";
        }
    }
}

if (filter_has_var(INPUT_POST, 'cambiar_contrasena')) {
    $usuario = filter_input(INPUT_POST, 'usuario_cambio', FILTER_SANITIZE_STRING);
    $nuevaContrasena = filter_input(INPUT_POST, 'nueva_contrasena', FILTER_SANITIZE_STRING);
    $confirmarContrasena = filter_input(INPUT_POST, 'confirmar_contrasena', FILTER_SANITIZE_STRING);

    // Validaciones básicas
    if (empty($usuario) || empty($nuevaContrasena) || empty($confirmarContrasena)) {
        $errores[] = "❌ Todos los campos son obligatorios.";
    } elseif ($nuevaContrasena !== $confirmarContrasena) {
        $errores[] = "❌ Las contraseñas no coinciden.";
    } else {
        try {
            // Verificar que el usuario existe
            $usuarioValido = Usuarios::obtenerUsuarioPorNombre($usuario);

            if ($usuarioValido) {
                // Cambiar la contraseña
                $nuevaContrasenaHash = password_hash($nuevaContrasena, PASSWORD_DEFAULT);
                $actualizado = Usuarios::actualizarContrasena($usuarioValido['id'], $nuevaContrasenaHash);

                if ($actualizado) {
                    $_SESSION['mensaje'] = "✅ Contraseña cambiada con éxito.";
                } else {
                    $errores[] = "❌ No se pudo cambiar la contraseña. Intenta de nuevo.";
                }
            } else {
                $errores[] = "❌ Usuario no encontrado.";
            }
        } catch (PDOException $e) {
            $errores[] = "❌ Error al conectar con la base de datos: " . $e->getMessage();
        }
    }
}


// Pasar los errores a la vista
$_SESSION['errores'] = $errores;

// Redirigir de nuevo a la página de inicio de sesión
header("Location: ../Vista/login.php");
exit();
?>  