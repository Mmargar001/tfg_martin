<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Actividades;  

// Verificar si el usuario es administrador
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: ../Vista/login.php");

}

// Manejar la eliminación de una actividad
if (isset($_POST['eliminar_actividad']) && isset($_POST['id']) && is_numeric($_POST['id'])) {
    $actividadId = $_POST['id'];
    Actividades::eliminarActividad($actividadId);
    header("Location: ../Vista/gestionActividades.php");

}

// Validar la duración
function validarDuracion($duracion) {
    return preg_match('/^\d{1,2}(\.\d{1,2})?[smh]$/', $duracion);
}

// Manejar la creación y edición de actividades
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['eliminar_actividad'])) {
    $id = isset($_POST['id']) ? $_POST['id'] : null;
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $duracion = $_POST['duracion'];
    $ubicacion = $_POST['ubicacion'];
    $precio = $_POST['precio'];
    $categoria = $_POST['categoria'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];

    if (!validarDuracion($duracion)) {
        echo "Duración inválida. Usa el formato correcto (ej. 10m, 2.5h).";

    }

    if (empty($id)) {
        // Crear nueva actividad
        Actividades::crearActividad($titulo, $descripcion, $duracion, $ubicacion, $precio, $categoria, $fecha, $hora);
    } else {
        // Editar actividad existente
        Actividades::editarActividad($id, $titulo, $descripcion, $duracion, $ubicacion, $precio, $categoria, $fecha, $hora);
    }
    header("Location: ../Vista/gestionActividades.php");

}
?>
