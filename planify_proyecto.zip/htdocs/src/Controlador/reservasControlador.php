<?php

session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Reservas;  // Asegúrate de tener los namespaces correctos

// Verificar autenticación del usuario
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../Vista/login.php');
    
}

$usuario_id = $_SESSION['usuario_id'];

// Crear una nueva reserva
if (isset($_POST['crear_reserva']) && isset($_POST['itinerario_id'])) {
    $itinerario_id = intval($_POST['itinerario_id']);
    
    // Obtener el costo total de las actividades del itinerario
    $monto = Reservas::obtenerCosteTotalActividades($itinerario_id);

    $reserva_id = Reservas::crearReserva($itinerario_id, $usuario_id, $monto);

    if ($reserva_id) {
        header("Location: ../Vista/gestionReservas.php?success=Reserva creada exitosamente.");
    } else {
        header("Location: ../Vista/gestionReservas.php?error=Error al crear la reserva.");
    }
 
}

// Confirmar una reserva
if (isset($_POST['confirmar_reserva']) && isset($_POST['reserva_id'])) {
    $reserva_id = intval($_POST['reserva_id']);

    $resultado = Reservas::confirmarReserva($reserva_id);

    if ($resultado) {
        header("Location: ../Vista/gestionReservas.php?success=Reserva confirmada exitosamente.");
    } else {
        header("Location: ../Vista/gestionReservas.php?error=Error al confirmar la reserva.");
    }
    
}

// Pagar una reserva
if (isset($_POST['pagar_reserva']) && isset($_POST['reserva_id'])) {
    $reserva_id = intval($_POST['reserva_id']);

    $resultado = Reservas::pagarReserva($reserva_id);

    if ($resultado) {
        header("Location: ../Vista/gestionReservas.php?success=Reserva pagada exitosamente.");
    } else {
        header("Location: ../Vista/gestionReservas.php?error=Error al pagar la reserva.");
    }
   
}

// Cancelar una reserva
if (isset($_POST['cancelar_reserva']) && isset($_POST['reserva_id'])) {
    $reserva_id = intval($_POST['reserva_id']);

    $resultado = Reservas::cancelarReserva($reserva_id);

    if ($resultado) {
        header("Location: ../Vista/gestionReservas.php?success=Reserva cancelada exitosamente.");
    } else {
        header("Location: ../Vista/gestionReservas.php?error=Error al cancelar la reserva.");
    }
    
}

// Eliminar una reserva
if (isset($_POST['eliminar_reserva']) && isset($_POST['reserva_id'])) {
    $reserva_id = intval($_POST['reserva_id']);

    $resultado = Reservas::eliminarReserva($reserva_id);

    if ($resultado) {
        header("Location: ../Vista/gestionReservas.php?success=Reserva eliminada exitosamente.");
    } else {
        header("Location: ../Vista/gestionReservas.php?error=Error al eliminar la reserva.");
    }
  
}
?>
