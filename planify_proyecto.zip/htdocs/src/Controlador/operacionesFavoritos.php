<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';

use proyecto\Modelo\Favoritos;  // Usar el espacio de nombres adecuado para Favoritos

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../Vista/login.php");
  
}

// Manejo de favoritos
if (isset($_POST['actividad_id'])) {
    $actividad_id = intval($_POST['actividad_id']);
    $usuario = $_SESSION['usuario_id'];

    if (Favoritos::esFavorito($usuario, $actividad_id)) {
        // Si ya está en favoritos, eliminarlo
        Favoritos::eliminarFavorito($usuario, $actividad_id);
    } else {
        // Si no está en favoritos, añadirlo
        Favoritos::agregarFavorito($usuario, $actividad_id);
    }

    header("Location: ../Vista/listadoActividades.php");
  
} else {
    header("Location: ../Vista/inicioCliente.php");
  
}
?>
