<?php 
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Usuarios;  // Asegúrate de usar el espacio de nombres correcto para Usuarios

$errores = [];
$success = null;

// Verificar que el usuario esté autenticado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../Vista/login.php');
    
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener la información del usuario para mostrarla en la vista
$usuario = Usuarios::obtenerUsuarioPorId($usuario_id);

// Verificar que el usuario existe en la base de datos
if (!$usuario) {
    header('Location: ../Vista/login.php');

}

// Asignar los valores a las variables
$nombre = $usuario['nombre'];
$email = $usuario['email'];
$telefono = $usuario['telefono'];

// Procesar la actualización del perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_perfil'])) {
    $nuevo_nombre = $_POST['nombre'];
    $nuevo_email = $_POST['email'];
    $nuevo_telefono = $_POST['telefono'];

    // Actualizar el perfil del usuario en la base de datos
    $resultado = Usuarios::actualizarUsuario($usuario_id, $nuevo_nombre, $nuevo_email, $nuevo_telefono);

    if ($resultado) {
        // Actualizar el nombre del usuario en la sesión
        $_SESSION['usuario'] = $nuevo_nombre;

        // Destruir la sesión después de la actualización del perfil
        session_unset();  // Borra todas las variables de sesión
        session_destroy();  // Destruye la sesión

        // Redirigir al login con mensaje de éxito
        $_SESSION['success'] = "Perfil actualizado correctamente. Por favor, inicie sesión.";
        header("Location: ../Vista/login.php");
    } else {
        $errores[] = "❌ Error al actualizar el perfil.";
    }
    $_SESSION['errores'] = $errores;
    header("Location: ../Vista/perfil.php");
    
}


?>
