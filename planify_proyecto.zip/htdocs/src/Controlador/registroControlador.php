<?php
session_start();
use proyecto\Modelo\Usuarios;
require_once __DIR__ . '/../../vendor/autoload.php';



$errores = [];
$mensaje_exito = '';

if (filter_has_var(INPUT_POST, 'registro')) {
    $usuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING);
    $contrasena = filter_input(INPUT_POST, 'contrasena', FILTER_SANITIZE_STRING);
    $confirmar_contrasena = filter_input(INPUT_POST, 'confirmar_contrasena', FILTER_SANITIZE_STRING);
    $tipo_usuario = filter_input(INPUT_POST, 'tipo_usuario', FILTER_SANITIZE_STRING);

    if (!empty($usuario) && !empty($contrasena) && !empty($confirmar_contrasena)) {
        if ($contrasena === $confirmar_contrasena) {
            try {
                // Verificar si el nombre de usuario ya existe
                $usuarioExistente = Usuarios::obtenerUsuarioPorNombre($usuario);  // Aquí usamos $usuario, no $nombre
                if ($usuarioExistente) {
                    $errores[] = "❌ El nombre de usuario ya está en uso.";
                } else {
                    // Encriptar la contraseña
                    $contrasena_hashed = password_hash($contrasena, PASSWORD_DEFAULT);
                    // Crear el nuevo usuario
                    $resultado = Usuarios::crearUsuario($usuario, $contrasena_hashed, $tipo_usuario);
                    if ($resultado) {
                        $mensaje_exito = "✔️ Registro exitoso. Ahora puedes <a href='../Vista/login.php'>iniciar sesión</a>.";
                    } else {
                        $errores[] = "❌ Error al registrar el usuario. Por favor, intenta de nuevo.";
                    }
                }
            } catch (PDOException $e) {
                $errores[] = "❌ Error de conexión con la base de datos: " . $e->getMessage();
            }
        } else {
            $errores[] = "❌ Las contraseñas no coinciden.";
        }
    } else {
        $errores[] = "❌ Por favor, completa todos los campos.";
    }
}

// Pasar los errores y mensajes a la vista
$_SESSION['errores'] = $errores;
$_SESSION['mensaje_exito'] = $mensaje_exito;

// Redirigir a la página de registro
header("Location: ../Vista/registro.php");

?>
