<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Comentarios;
// Verificar que el usuario esté autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../Vista/login.php");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['agregar_comentario'])) {
        // Agregar comentario
        if (isset($_POST['actividad_id'], $_POST['comentario'], $_POST['puntuacion'])) {
            $actividad_id = intval($_POST['actividad_id']);
            $comentario = trim($_POST['comentario']);
            $puntuacion = intval($_POST['puntuacion']);
            $usuario = $_SESSION['usuario_id'];

            // Validar la puntuación
            if ($puntuacion < 1 || $puntuacion > 5) {
                $error = 'La puntuación debe estar entre 1 y 5.';
                header("Location: ../Vista/detallesActividad.php?id=$actividad_id&error=" . urlencode($error));
              
            }

            // Crear el comentario
            Comentarios::crearComentario($usuario, $actividad_id, $comentario, $puntuacion);

            header("Location: ../Vista/detallesActividad.php?id=$actividad_id");
     
        }
    } elseif (isset($_POST['eliminar_comentario'])) {
        // Eliminar comentario
        if (isset($_POST['comentario_id'], $_POST['actividad_id'])) {
            $comentario_id = intval($_POST['comentario_id']);
            $actividad_id = intval($_POST['actividad_id']);
            $usuario = $_SESSION['usuario_id'];

            // Verificar que el comentario pertenece al usuario
            $comentario = Comentarios::obtenerComentarioPorId($comentario_id);
            if ($comentario && $comentario['usuario_id'] == $usuario) {
                Comentarios::eliminarComentario($comentario_id);
            }

            header("Location: ../Vista/detallesActividad.php?id=$actividad_id");
      
        }
    } else {
        // Si la solicitud no es válida
        header("Location: ../Vista/detallesActividad.php?id=" . intval($_POST['actividad_id']));
   
    }
} else {
    // Solicitud no válida
    header("Location: ../Vista/detallesActividad.php");
 
}
?>
