<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';

use proyecto\Modelo\Itinerarios;
use proyecto\Modelo\Usuarios;

// Verificar si el usuario tiene acceso
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: ../Vista/login.php");
}

// Obtener los itinerarios con los filtros aplicados
$usuario_id = isset($_GET['usuario_id']) ? $_GET['usuario_id'] : null;
$fecha_creacion = isset($_GET['fecha_creacion']) ? $_GET['fecha_creacion'] : null;

$itinerarios = Itinerarios::obtenerItinerariosFiltrados($usuario_id, $fecha_creacion);

// Obtener todos los usuarios
$usuarios = Usuarios::obtenerUsuarios();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Itinerarios</title>
    <link rel="stylesheet" href="../Estilos/estilosComunes.css">
    <style>
        /* Estilo para el formulario de edición que aparecerá sobre la tabla */
        #formulario-edicion {
            display: none;  /* Inicialmente oculto */
            position: fixed;  /* Aparecerá sobre la página */
            top: 20%;  /* Puedes ajustar la posición según tus necesidades */
            left: 50%;
            transform: translateX(-50%);
            background-color: white;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            z-index: 1000;  /* Asegura que el formulario esté por encima de otros elementos */
        }

        /* Fondo oscuro para el modal de edición */
        #fondo-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        /* Estilo de la tabla */
        .table-itinerarios {
            width: 100%;
            border-collapse: collapse;
        }

        .table-itinerarios th, .table-itinerarios td {
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .form-filtros {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <div class="container">
        <header class="header">
            <h1>Gestión de Itinerarios</h1>
            <a href="inicioAdmin.php" class="a">Volver al área de administración</a>
        </header>

        <!-- Formulario de edición (inicialmente oculto) -->
        <div id="fondo-overlay"></div>
        <div id="formulario-edicion">
            <h2>Editar Itinerario</h2>
            <form id="form-editar-itinerario" method="post" action="../Controlador/operacionesItinerario.php">
    <input type="hidden" name="itinerario_id" id="itinerario_id" />
    <div>
        <label for="nombre">Nombre</label>
        <input type="text" name="nombre" id="nombre" required>
    </div>
    <div>
        <button type="submit" name="editar_itinerario">Guardar cambios</button>
        <button type="button" id="cancelar-editar">Cancelar</button>
    </div>
</form>

        </div>

        <!-- Filtros de búsqueda -->
        <form method="get" action="gestionItinerarios.php" class="form-filtros">
            <div>
                <label for="usuario_id">Selecciona un Usuario:</label>
                <select name="usuario_id" id="usuario_id">
                    <option value="">Seleccione un usuario</option>
                    <?php foreach ($usuarios as $usuario): ?>
                        <option value="<?php echo $usuario['id']; ?>" <?php echo $usuario['id'] == $usuario_id ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($usuario['nombre']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="fecha_creacion">Fecha de Creación:</label>
                <input type="date" name="fecha_creacion" id="fecha_creacion" value="<?php echo htmlspecialchars($fecha_creacion); ?>">
            </div>
            <div>
                <button type="submit">Filtrar</button>
            </div>
        </form>

        <!-- Tabla de itinerarios -->
        <table class="table-itinerarios">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Fecha Creación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($itinerarios)): ?>
                    <tr>
                        <td colspan="4">No se encontraron itinerarios.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($itinerarios as $itinerario): ?>
                        <tr>
                            <td><?php echo $itinerario['id']; ?></td>
                            <td><?php echo htmlspecialchars($itinerario['nombre']); ?></td>
                            <td><?php echo htmlspecialchars($itinerario['fecha_creacion']); ?></td>
                            <td>
                                <button class="editar-btn" data-id="<?php echo $itinerario['id']; ?>" data-nombre="<?php echo htmlspecialchars($itinerario['nombre']); ?>" data-fecha="<?php echo htmlspecialchars($itinerario['fecha_creacion']); ?>">Editar</button>
                                <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                                    <input type="hidden" name="itinerario_id" value="<?php echo $itinerario['id']; ?>" />
                                    <button type="submit" name="eliminar_itinerario">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script>
        // Mostrar el formulario de edición al hacer clic en el botón de editar
        document.querySelectorAll('.editar-btn').forEach(function(button) {
            button.addEventListener('click', function() {
                // Mostrar el formulario y el fondo oscuro
                document.getElementById('formulario-edicion').style.display = 'block';
                document.getElementById('fondo-overlay').style.display = 'block';

                // Rellenar los campos del formulario con los datos del itinerario
                document.getElementById('itinerario_id').value = this.getAttribute('data-id');
                document.getElementById('nombre').value = this.getAttribute('data-nombre');
                document.getElementById('fecha_creacion').value = this.getAttribute('data-fecha');
            });
        });

        // Ocultar el formulario de edición cuando se haga clic en cancelar
        document.getElementById('cancelar-editar').addEventListener('click', function() {
            document.getElementById('formulario-edicion').style.display = 'none';
            document.getElementById('fondo-overlay').style.display = 'none';
        });

        // Cerrar el formulario si se hace clic en el fondo oscuro
        document.getElementById('fondo-overlay').addEventListener('click', function() {
            document.getElementById('formulario-edicion').style.display = 'none';
            document.getElementById('fondo-overlay').style.display = 'none';
        });
    </script>

</body>
</html>


