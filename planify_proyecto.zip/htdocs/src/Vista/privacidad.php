<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
// Verificar que el usuario esté autenticado y sea administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'cliente') {
    header('Location: ../Vista/login.php');
    exit();
}
?> 
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fef6e4;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            background-color: #ffcb77;
            padding: 20px;
            border-bottom: 4px solid #d4a373;
        }

        .header h1 {
            margin: 0;
            color: #333;
        }

        .main-content {
            padding: 20px;
        }

        .main-content h2 {
            font-size: 1.8em;
            color: #333;
            margin-top: 30px;
        }

        .main-content p {
            margin: 10px 0;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Política de Privacidad</h1>
        </header>
        <main class="main-content">
            <h2>Introducción</h2>
            <p>En nuestra empresa, valoramos tu privacidad y nos comprometemos a proteger la información personal que compartes con nosotros.</p>
            
            <h2>Información que Recopilamos</h2>
            <p>Podemos recopilar información personal como tu nombre, dirección de correo electrónico, y cualquier otra información que decidas compartir con nosotros.</p>
            
            <h2>Uso de la Información</h2>
            <p>Utilizamos tu información para proporcionar y mejorar nuestros servicios, comunicarnos contigo y cumplir con obligaciones legales.</p>
            
            <h2>Compartir Información</h2>
            <p>No compartiremos tu información personal con terceros, excepto cuando sea necesario para proporcionar nuestros servicios o cuando lo exija la ley.</p>
            
            <h2>Seguridad</h2>
            <p>Implementamos medidas de seguridad razonables para proteger tu información personal contra acceso no autorizado, pérdida o destrucción.</p>
            
            <h2>Contactar con Nosotros</h2>
            <p>Si tienes alguna pregunta sobre nuestra política de privacidad, puedes contactarnos a través de la página de <a href="contacto.html" style="color: #e76f51; text-decoration: none;">Contacto</a>.</p>
        </main>
    </div>
</body>
</html>
