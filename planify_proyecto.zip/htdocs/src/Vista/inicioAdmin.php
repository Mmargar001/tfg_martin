<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
// Verificar que el usuario esté autenticado y sea administrador
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: ../Vista/login.php");
    
}
?> 
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área de Administración</title>
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
</head>
<body>
    <div class="admin-container">
        <!-- Encabezado -->
        <header class="header">
            <h1>Panel de Administración</h1>
            <nav class="header-nav">
                <!-- Enlace para volver al login -->
                <a href="login.php" class="header-link">Volver al Login</a>
            </nav>
        </header>

        <!-- Navegación lateral -->
        <nav class="nav">
            <ul class="nav-list">
                <!-- Enlaces para gestionar distintas secciones -->
                <li class="nav-item"><a href="gestionUsuarios.php" class="nav-link">Gestionar Usuarios</a></li>
                <li class="nav-item"><a href="gestionActividades.php" class="nav-link">Gestionar Actividades</a></li>
                 <li class="nav-item"><a href="perfil.php" class="nav-link">Mi Perfil</a></li>
                <li class="nav-item"><a href="gestionItinerarios.php" class="nav-link">Gestionar Itinerarios</a></li>
                <li class="nav-item"><a href="gestionNotificaciones.php" class="nav-link">Gestionar Notificaciones</a></li>
            </ul>
        </nav>

        <!-- Contenido principal -->
        <main class="main-content">
            <section class="section welcome">
                <h2 class="section-title">Bienvenido, Administrador</h2>
                <p>Utilice el menú de navegación para gestionar usuarios, actividades, itinerarios y notificaciones.</p>
            </section>
        </main>

        <!-- Pie de página -->
        <footer class="footer">
            <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
        </footer>
    </div>
</body>
</html>
