<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Actividades;  
use proyecto\Modelo\Categorias;
use proyecto\Modelo\Favoritos;  
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente')
{
    header("Location: ../Vista/login.php");
    
}

// Obtener todas las categorías y actividades
$categorias = Categorias::obtenerCategorias();
$actividades = Actividades::obtenerActividades();
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <!-- Otras etiquetas meta y títulos -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Listado de Actividades</title>
        <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    </head>
    <body>
        <div class="client-container">
            <header class="header">
                <h1>Listado de Actividades</h1>
                 <a href="inicioCliente.php" >Volver al área del cliente</a>
            </header>
            <main class="main-content">
                <section class="activity-list">
                    <h2>Actividades Disponibles</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Título</th>
                                <th>Descripción</th>
                                <th>Duración</th>
                                <th>Ubicación</th>
                                <th>Precio</th>
                                <th>Categoría</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($actividades as $actividad): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($actividad['id']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['titulo']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['descripcion']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['duracion']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['ubicacion']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['precio']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['categoria']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['fecha']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['hora']); ?></td>
                                    <td>
                                    <td>
                                        <!-- Añadir/Quitar de Favoritos con ícono de corazón -->
                                        <form action="../Controlador/operacionesFavoritos.php" method="post" style="display:inline;">
                                            <input type="hidden" name="actividad_id" value="<?php echo htmlspecialchars($actividad['id']); ?>">
                                            <input type="hidden" name="toggle_favorito" value="1">
                                            <button type="submit" class="save-button">
                                                <?php if (Favoritos::esFavorito($_SESSION['usuario_id'], $actividad['id'])): ?>
                                                    <i class="fas fa-heart"></i> <!-- Corazón para favoritos -->
                                                <?php else: ?>
                                                    <i class="far fa-heart"></i> <!-- Corazón para no favoritos -->
                                                <?php endif; ?>
                                            </button>
                                        </form>

                                        <!-- Ver Comentarios como botón -->
                                        <form action="comentariosActividad.php" method="get" style="display:inline;">
                                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($actividad['id']); ?>">
                                            <button type="submit" class="button">Ver Comentarios</button>
                                        </form>
                                    </td>

                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </section>
                <section class="volver-perfil">
                   
                </section>
            </main>
            <footer class="footer">
                <div class="footer-container">
                    <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
                </div>
            </footer>
        </div>
    </body>
</html>
