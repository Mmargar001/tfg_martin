<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Itinerarios;
use proyecto\Modelo\Reservas;
// Verificar autenticación del usuario
if (!isset($_SESSION['usuario_id']))
{
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener las reservas del usuario
$reservas = Reservas::obtenerReservasPorUsuario($usuario_id);

// Obtener los itinerarios disponibles para el usuario
$itinerarios = Itinerarios::obtenerItinerariosPorUsuario($usuario_id);

// Obtener las actividades asociadas a cada itinerario
$itinerariosConActividades = [];
foreach ($itinerarios as $itinerario)
{
    $itinerario['actividades'] = Itinerarios::obtenerActividadesPorItinerario($itinerario['id']);
    $itinerariosConActividades[] = $itinerario;
}

// Mostrar mensajes de éxito o error
$success_message = isset($_GET['success']) ? htmlspecialchars($_GET['success']) : null;
$error_message = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : null;
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gestión de Reservas</title>
        <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    </head>
    <body>
        <div class="client-container">
            <header class="header">
                <h1 class="welcome-message">Itinerarios Creados</h1>
                <nav class="header-nav">
                    <a href="inicioCliente.php" class="header-link">Volver al Inicio</a>
                </nav>
            </header>



            <main class="main-content">
                <section class="section">
               
                    <h2 class="section-title">Mis Itinerarios</h2>

                    <!-- Mensajes de éxito o error, si existen -->
                    <?php if ($success_message): ?>
                        <p class="success-message"><?php echo htmlspecialchars($success_message); ?></p>
                    <?php elseif ($error_message): ?>
                        <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
                    <?php endif; ?>

                    <!-- Verificación si el usuario tiene itinerarios creados -->
                    <?php if (empty($itinerariosConActividades)): ?>
                        <!-- Mensaje cuando no hay itinerarios -->
                        <p>No tienes itinerarios creados. <a href="crearItinerario.php">Crea uno aquí</a>.</p>
                    <?php else: ?>
                        
                        <!-- Itera sobre los itinerarios creados por el usuario -->
    <?php foreach ($itinerariosConActividades as $itinerario): ?>
                            <div class="card">
                                <div class="card-content">
                                    <!-- Muestra el nombre y la descripción del itinerario -->
                                    <h3>Itinerario: <?php echo htmlspecialchars($itinerario['nombre']); ?></h3>
                                    <p>Descripción: <?php echo htmlspecialchars($itinerario['descripcion']); ?></p>

                                    <!-- Verificación si el itinerario tiene actividades -->
        <?php if (!empty($itinerario['actividades'])): ?>
                                        <p>Actividades: <?php echo count($itinerario['actividades']); ?></p>
                                        <ul>
                                            <!-- Muestra una lista con los títulos de las actividades -->
                                            <?php foreach ($itinerario['actividades'] as $actividad): ?>
                                                <li><?php echo htmlspecialchars($actividad['titulo']); ?></li>
                                        <?php endforeach; ?>
                                        </ul>
                                    <?php else: ?>
                                        <p>No hay actividades añadidas a este itinerario.</p>
                                    <?php endif; ?>

                                    <!-- Verificación si hay reservas existentes para el itinerario -->
                                    <?php
                                    $reservaExistente = false;
                                    $reserva = null;
                                    foreach ($reservas as $r)
                                    {
                                        if ($r['itinerario_id'] == $itinerario['id'])
                                        {
                                            $reservaExistente = true;
                                            $reserva = $r;
                                            break;
                                        }
                                    }
                                    ?>

                                    <!-- Botón para modificar actividades si no hay reserva pagada -->
                                    <?php if (!$reservaExistente || ($reservaExistente && $reserva['estado'] !== 'pagada'&& $reserva['estado'] !== 'cancelada')): ?>
                                        <form action="../Vista/gestionClienteItinerarios.php" method="get">
                                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($itinerario['id']); ?>">
                                            <button type="submit" class="button ">Modificar Actividades</button>
                                        </form>
        <?php endif; ?>

                                    <!-- Botón para eliminar el itinerario si no hay reserva pagada -->
                                    <?php if (!$reservaExistente || ($reservaExistente && $reserva['estado'] !== 'pagada')): ?>
                                        <form action="../Controlador/operacionesItinerario.php" method="post">
                                            <input type="hidden" name="itinerario_id" value="<?php echo htmlspecialchars($itinerario['id']); ?>">
                                            <button type="submit" name="eliminar_itinerario" class="delete-button">Eliminar Itinerario</button>
                                        </form>
        <?php endif; ?>

                                    <!-- Opciones relacionadas con la reserva -->
                                    <?php if ($reservaExistente): ?>
                                        <p><strong>Estado de la reserva: <?php echo htmlspecialchars($reserva['estado']); ?></strong></p>

                                        <!-- Botón para cancelar la reserva si el estado es pendiente o pagada -->
                                        <?php if ($reserva['estado'] === 'pendiente' || $reserva['estado'] === 'pagada'): ?>
                                            <form action="../Controlador/reservasControlador.php" method="post">
                                                <input type="hidden" name="reserva_id" value="<?php echo htmlspecialchars($reserva['id']); ?>">
                                                <button type="submit" name="cancelar_reserva" class="button secondary">Cancelar Reserva</button>
                                            </form>
            <?php endif; ?>

                                        <!-- Botón para pagar la reserva si está pendiente -->
                                        <?php if ($reserva['estado'] === 'pendiente'): ?>
                                            <form action="../Controlador/reservasControlador.php" method="post">
                                                <input type="hidden" name="reserva_id" value="<?php echo htmlspecialchars($reserva['id']); ?>">
                                                <button type="submit" name="pagar_reserva" class="button success">Pagar Reserva</button>
                                            </form>
            <?php endif; ?>
        <?php else: ?>
                                        <!-- Mostrar el botón de crear reserva solo si hay actividades asociadas -->
                                        <?php if (!empty($itinerario['actividades'])): ?>
                                            <form action="../Controlador/reservasControlador.php" method="post">
                                                <input type="hidden" name="itinerario_id" value="<?php echo htmlspecialchars($itinerario['id']); ?>">
                                                <button type="submit" name="crear_reserva" class="button primary">Crear Reserva</button>
                                            </form>
                                <?php endif; ?>
                            <?php endif; ?>
                                </div>
                            </div>
    <?php endforeach; ?>
<?php endif; ?>
                </section>
            </main>


            <footer class="footer">
                <div class="footer-container">
                    <div class="footer-column">
                        <h3>Enlaces Útiles</h3>
                        <ul class="footer-list">
                            <li><a href="nosotros.php" class="footer-link">Sobre Nosotros</a></li>
                            <li><a href="contacto.php" class="footer-link">Contacto</a></li>
                            <li><a href="privacidad.php" class="footer-link">Política de Privacidad</a></li>
                            <li><a href="terminos.php" class="footer-link">Términos y Condiciones</a></li>
                        </ul>
                    </div>
                    <div class="footer-column">
                        <h3>Síguenos</h3>
                        <ul class="footer-list">
                            <li><a href="#" class="footer-link">Facebook</a></li>
                            <li><a href="#" class="footer-link">Twitter</a></li>
                            <li><a href="#" class="footer-link">Instagram</a></li>
                            <li><a href="#" class="footer-link">LinkedIn</a></li>
                        </ul>
                    </div>
                </div>
            </footer>
        </div>
    </body>
</html>
