<?php
// Iniciar sesión para acceder a las variables de sesión
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Notificaciones;
// Verificar que el usuario esté autenticado y tenga el rol de 'cliente'
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'cliente') {
    // Redirigir al usuario a la página de login si no está autenticado o no es un cliente
    header('Location: ../Vista/login.php');
    
}

// Incluir el modelo de Notificaciones
require_once '../Modelo/Notificaciones.php';

// Obtener el ID del usuario desde la sesión
$usuario = $_SESSION['usuario_id'];

// Obtener las notificaciones del usuario desde el modelo
$notificaciones = Notificaciones::obtenerNotificaciones($usuario);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificaciones</title>
    <!-- Incluir hojas de estilo para el diseño -->
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
</head>
<body>
    <div class="client-container">
        <header class="header">
            <?php if (isset($_SESSION['usuario'])): ?>
                <!-- Mostrar el nombre del usuario en el encabezado -->
                <h1 class="welcome-message">Notificaciones de <?php echo htmlspecialchars($_SESSION['usuario']); ?></h1>
            <?php else: ?>
                <?php 
                // Redirigir a la página de inicio si el usuario no está autenticado
                header('Location: ../Vista/login.php');
                
                ?>
            <?php endif; ?>
            <nav class="header-nav">
                <!-- Enlace para volver al perfil del cliente -->
                <a href="../Vista/inicioCliente.php" class="header-link">Volver a Mi Perfil</a>
            </nav>
        </header>
        <main class="main-content">
            <section class="section">
                <h2 class="section-title">Tus Notificaciones</h2>
                <?php if (empty($notificaciones)): ?>
                    <!-- Mensaje si no hay notificaciones -->
                    <p>No tienes notificaciones.</p>
                <?php else: ?>
                    <ul class="notification-list">
                        <?php foreach ($notificaciones as $notificacion): ?>
                            <li class="notification-item <?php echo $notificacion['leida'] == 1 ? 'read' : 'unread'; ?>">
                                <p><?php echo htmlspecialchars($notificacion['mensaje']); ?></p>
                                <!-- Formulario para marcar la notificación como leída -->
                                <form method="post" action="../Controlador/notificacionesController.php" class="mark-read-form">
                                    <input type="hidden" name="notificacion_id" value="<?php echo $notificacion['id']; ?>">
                                    <?php if ($notificacion['leida'] == 0): ?>
                                        <!-- Botón para marcar la notificación como leída solo si no está leída -->
                                        <button type="submit" name="marcar_leida" class="card-link secondary">Marcar como Leída</button>
                                        <button type="submit" name="marcar_todas_leidas" class="card-link primary">Marcar Todas como Leídas</button>
                                    <?php endif; ?>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>
</html>
