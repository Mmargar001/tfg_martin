<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Usuarios;

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../Vista/login.php');
    
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener la información del usuario desde la base de datos
$usuario = Usuarios::obtenerUsuarioPorId($usuario_id);
if ($usuario) {
    $nombre = $usuario['nombre'];
    $email = $usuario['email'];
    $telefono = $usuario['telefono'];
} else {
    $nombre = $email = $telefono = '';
}
// Suponiendo que hay un campo `tipo_usuario` que define si el usuario es administrador o cliente
$tipo_usuario = $usuario['tipo'];  // Puede ser 'admin' o 'cliente'
?>
<?php 
// Mensajes de error y éxito desde la sesión
$errores = $_SESSION['errores'] ?? [];
$success = $_SESSION['success'] ?? null;

// Limpiar mensajes de la sesión
unset($_SESSION['errores']);
unset($_SESSION['success']);
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil</title>
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    <style>
        .hidden { display: none; }
    </style>
</head>
<body>
    <div class="client-container">
        <header class="header">
            <h1>Mi Perfil</h1>
    <?php if ($tipo_usuario == 'administrador'): ?>
        <a href="inicioAdmin.php" class="a">Volver al área de administración</a>
    <?php else: ?>
        <a href="inicioCliente.php" class="a">Volver al área del cliente</a>
    <?php endif; ?>
        </header>
        <main class="main-content">
            <div class="container">
                <h2>Información Personal</h2>
                <ul>
                    <li><strong>Nombre:</strong> <?php echo htmlspecialchars($nombre); ?></li>
                    <li><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></li>
                    <li><strong>Teléfono:</strong> <?php echo htmlspecialchars($telefono); ?></li>
                </ul>
                <button id="modify-profile-button" class="button">Modificar Perfil</button>
                <form id="modify-profile-form" method="post" class="profile-form hidden" action="../Controlador/operacionesPerfil.php">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required>
                    <label for="email">Email:</label>
                    <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                    <label for="telefono">Teléfono:</label>
                    <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($telefono); ?>" required>
                    <input type="hidden" name="actualizar_perfil" value="1">
                    <button type="submit" class="button">Actualizar</button>
                </form>
            </div>

            
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let modifyProfileButton = document.getElementById('modify-profile-button');
            let modifyProfileForm = document.getElementById('modify-profile-form');
            if (modifyProfileButton && modifyProfileForm) {
                modifyProfileButton.addEventListener('click', function(event) {
                    event.preventDefault();
                    modifyProfileForm.classList.toggle('hidden');
                });
            }
        });
    </script>
</body>
</html>
