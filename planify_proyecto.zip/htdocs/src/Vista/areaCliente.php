<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Actividades;  
use proyecto\Modelo\Comentarios;
use proyecto\Modelo\Favoritos;  
use proyecto\Modelo\Itinerarios;
// Verificar si el usuario está autenticado y tiene el rol de cliente
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'cliente') {
    header("Location: ../Vista/login.php");
   
}

// Obtener el ID del itinerario desde la URL
$itinerario_id = isset($_GET['id']) ? intval($_GET['id']) : null;
if (!$itinerario_id) {
    header("Location: areaClente.php");
  
}

// Obtener detalles del itinerario y verificar que pertenece al usuario
$itinerario = Itinerarios::obtenerItinerarioPorId($itinerario_id);
if (!$itinerario || $itinerario['usuario_id'] != $_SESSION['usuario_id']) {
    header("Location:areaCliente.php");
}

// Obtener actividades asociadas al itinerario
$actividadesAsociadas = Itinerarios::obtenerActividadesPorItinerario($itinerario_id);

// Obtener todas las actividades disponibles para agregar
$todasActividades = Actividades::obtenerActividades();
$actividadesDisponibles = array_filter($todasActividades, function ($actividad) use ($actividadesAsociadas) {
    foreach ($actividadesAsociadas as $asociada) {
        if ($asociada['id'] == $actividad['id']) {
            return false; // Excluir actividades ya asociadas
        }
    }
    return true;
});

// Obtener puntuación promedio para cada actividad
foreach ($actividadesAsociadas as &$actividad) {
    $actividad['puntuacion_promedio'] = Comentarios::obtenerPuntuacionPromedio($actividad['id']);
}
foreach ($actividadesDisponibles as &$actividad) {
    $actividad['puntuacion_promedio'] = Comentarios::obtenerPuntuacionPromedio($actividad['id']);
}

// Manejar los filtros
$fechaFiltro = isset($_POST['fecha']) ? $_POST['fecha'] : null;
$horaFiltro = isset($_POST['hora']) ? $_POST['hora'] : null;
$puntuacionFiltro = isset($_POST['puntuacion']) ? floatval($_POST['puntuacion']) : null;
$favoritosFiltro = isset($_POST['favoritos']) ? (bool)$_POST['favoritos'] : false;
$precioFiltro = isset($_POST['precio']) ? floatval($_POST['precio']) : null;

$actividadesFiltradas = array_filter($actividadesDisponibles, function ($actividad) use ($fechaFiltro, $horaFiltro, $puntuacionFiltro, $favoritosFiltro, $precioFiltro) {
    $dentroFecha = (!$fechaFiltro || $actividad['fecha'] === $fechaFiltro);
    $dentroHora = (!$horaFiltro || $actividad['hora'] === $horaFiltro);
    $dentroPuntuacion = ($puntuacionFiltro === null || $actividad['puntuacion_promedio'] >= $puntuacionFiltro);
    $esFavorita = (!$favoritosFiltro || Favoritos::esFavorito($_SESSION['usuario_id'], $actividad['id']));
    $dentroPrecio = (!$precioFiltro || $actividad['precio'] <= $precioFiltro);

    // Mostrar la actividad si cumple con todos los filtros seleccionados
    return $dentroFecha && $dentroHora && $dentroPuntuacion && $esFavorita && $dentroPrecio;
});

// Obtener el mensaje de error o éxito si existe
$error = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : null;
$success = isset($_GET['success']) ? htmlspecialchars($_GET['success']) : null;

// Verificar si hay actividades en el itinerario
$hayActividadesEnItinerario = !empty($actividadesAsociadas);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Metadatos para establecer la codificación de caracteres y la adaptabilidad a dispositivos móviles -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Título de la página, se mostrará en la pestaña del navegador -->
    <title>Gestión de Itinerario</title>

    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">

  
</head>
<body>
    <!-- Contenedor principal para gestionar el itinerario -->
    <div class="gestion-itinerario-container">
        
        <!-- Cabecera con el título que muestra el nombre del itinerario -->
        <header class="header">
            <h1>Gestión de Itinerario: <?php echo htmlspecialchars($itinerario['nombre']); ?></h1>
        </header>

        <main class="main-content">
            <!-- Bloque para mostrar mensajes de error o éxito -->
            <?php if ($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- Bloque que muestra los detalles del itinerario y sus actividades -->
            <section class="itinerario-detalle">
                <h2>Actividades en este Itinerario</h2>
                <!-- Muestra el presupuesto total del itinerario -->
                <p><strong>Presupuesto total del Itinerario:</strong> <?php echo htmlspecialchars($itinerario['presupuesto']); ?> €</p>

                <!-- Verifica si hay actividades asociadas al itinerario y las muestra en una lista -->
                <?php if (empty($actividadesAsociadas)): ?>
                    <p>No hay actividades en este itinerario.</p>
                <?php else: ?>
                    <ul>
                        <!-- Itera sobre las actividades asociadas y las muestra con sus detalles -->
                        <?php foreach ($actividadesAsociadas as $actividad): ?>
                            <li>
                                <h3><?php echo htmlspecialchars($actividad['titulo']); ?></h3>
                                <p><?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                                <p>Fecha: <?php echo htmlspecialchars($actividad['fecha']); ?></p>
                                <p>Hora: <?php echo htmlspecialchars($actividad['hora']); ?></p>
                                <p>Duración: <?php echo htmlspecialchars($actividad['duracion']); ?> horas</p>
                                <p>Precio: <?php echo htmlspecialchars($actividad['precio']); ?> €</p>
                                <!-- Formulario para eliminar la actividad del itinerario -->
                                <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                                    <input type="hidden" name="itinerario_id" value="<?php echo $itinerario_id; ?>">
                                    <input type="hidden" name="actividad_id" value="<?php echo $actividad['id']; ?>">
                                    <button type="submit" name="eliminar_actividad" class="delete-button">Eliminar Actividad</button>
                                </form>
                                <!-- Si la actividad no ha sido abonada, se muestra el botón para pagar -->
                                <?php if (!$actividad['abonado']): ?>
                                    <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                                        <input type="hidden" name="itinerario_id" value="<?php echo $itinerario_id; ?>">
                                        <input type="hidden" name="actividad_id" value="<?php echo $actividad['id']; ?>">
                                        <button type="submit" name="abonar_actividad" class="pay-button">Pagar Actividad</button>
                                    </form>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>

            <!-- Bloque para agregar nuevas actividades con filtros de búsqueda -->
            <section class="agregar-actividades">
                <h2>Agregar Nuevas Actividades</h2>
                <form method="post" action="">
                    <!-- Filtros para buscar actividades por fecha, hora, puntuación, precio y favoritos -->
                    <div class="form-group">
                        <label for="fecha">Filtrar por Fecha:</label>
                        <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($fechaFiltro); ?>">
                    </div>
                    <div class="form-group">
                        <label for="hora">Filtrar por Hora:</label>
                        <input type="time" id="hora" name="hora" value="<?php echo htmlspecialchars($horaFiltro); ?>">
                    </div>
                    <div class="form-group">
                        <label for="puntuacion">Filtrar por Puntuación:</label>
                        <select id="puntuacion" name="puntuacion">
                            <option value="">Cualquier Puntuación</option>
                            <option value="1" <?php echo $puntuacionFiltro == 1 ? 'selected' : ''; ?>>1</option>
                            <option value="2" <?php echo $puntuacionFiltro == 2 ? 'selected' : ''; ?>>2</option>
                            <option value="3" <?php echo $puntuacionFiltro == 3 ? 'selected' : ''; ?>>3</option>
                            <option value="4" <?php echo $puntuacionFiltro == 4 ? 'selected' : ''; ?>>4</option>
                            <option value="5" <?php echo $puntuacionFiltro == 5 ? 'selected' : ''; ?>>5</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="precio">Filtrar por Precio:</label>
                        <input type="number" id="precio" name="precio" value="<?php echo htmlspecialchars($precioFiltro); ?>" step="0.01" min="0" placeholder="Precio máximo">
                    </div>
                    <div class="form-group">
                        <label for="favoritos">Mostrar solo Favoritos:</label>
                        <input type="checkbox" id="favoritos" name="favoritos" value="1" <?php echo $favoritosFiltro ? 'checked' : ''; ?>>
                    </div>
                    <button type="submit" class="filter-button">Filtrar</button>
                </form>

                <!-- Muestra las actividades que coinciden con los filtros aplicados -->
                <?php if (!empty($actividadesFiltradas)): ?>
                    <ul>
                        <?php foreach ($actividadesFiltradas as $actividad): ?>
                            <li>
                                <h3><?php echo htmlspecialchars($actividad['titulo']); ?></h3>
                                <p><?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                                <p>Fecha: <?php echo htmlspecialchars($actividad['fecha']); ?></p>
                                <p>Hora: <?php echo htmlspecialchars($actividad['hora']); ?></p>
                                <p>Duración: <?php echo htmlspecialchars($actividad['duracion']); ?> horas</p>
                                <p>Precio: <?php echo htmlspecialchars($actividad['precio']); ?> €</p>
                                <!-- Formulario para agregar la actividad al itinerario -->
                                <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                                    <input type="hidden" name="itinerario_id" value="<?php echo $itinerario_id; ?>">
                                    <input type="hidden" name="actividad_id" value="<?php echo $actividad['id']; ?>">
                                    <button type="submit" name="agregar_actividad" class="add-button">Agregar al Itinerario</button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No hay actividades disponibles para agregar con los filtros seleccionados.</p>
                <?php endif; ?>
            </section>

            <!-- Sección con botones para realizar acciones en el itinerario -->
            <section class="botones">
                <!-- Mostrar el botón para pagar el itinerario si tiene actividades asociadas -->
                <?php if ($hayActividadesEnItinerario): ?>
                    <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                        <input type="hidden" name="itinerario_id" value="<?php echo $itinerario_id; ?>">
                        <button type="submit" name="pagar_itinerario" class="pay-itinerary-button">Pagar Itinerario</button>
                    </form>
                <?php endif; ?>

                <!-- Botón para eliminar el itinerario -->
                <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                    <input type="hidden" name="itinerario_id" value="<?php echo $itinerario_id; ?>">
                    <button type="submit" name="eliminar_itinerario" class="delete-button">Eliminar Itinerario</button>
                </form>
                
                <!-- Enlace para volver al área del cliente -->
                <a href="areaCliente.php" class="button">Volver al área del cliente</a>
            </section>
        </main>
    </div>
</body>
</html>

