<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';

use proyecto\Modelo\Usuarios;

// Verificar que el usuario esté autenticado y sea administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'administrador') {
    header('Location: ../Vista/login.php');
}

// Obtener el ID del usuario actual
$usuarioIdActual = $_SESSION['usuario_id'];

// Manejar la eliminación de un usuario
if (isset($_GET['eliminar']) && is_numeric($_GET['eliminar'])) {
    $usuarioId = $_GET['eliminar'];
    Usuarios::eliminarUsuario($usuarioId);
    header("Location: gestionUsuarios.php");
}

// Obtener la lista de usuarios, excluyendo al usuario actual
$usuarios = Usuarios::obtenerUsuarios();
$usuarios = array_filter($usuarios, function($usuario) use ($usuarioIdActual) {
    return $usuario['id'] != $usuarioIdActual;
});
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    <title>Gestión de Usuarios</title>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Gestión de Usuarios</h1>
            <a href="inicioAdmin.php" class="a">Volver al área de administración</a>
        </header>

        <main class="main-content">
            <!-- Botón para crear un nuevo usuario -->
            <button onclick="window.location.href='registro.php?admin=true'" class="create-button">Crear Usuario</button>
            
            <!-- Tabla con los usuarios -->
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Teléfono</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Itera a través de los usuarios y muestra sus detalles -->
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr>
                            <!-- Muestra los datos del usuario -->
                            <td><?php echo htmlspecialchars($usuario['nombre']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['telefono']); ?></td>
                            <td>
                                <!-- Solo el botón de eliminación con confirmación -->
                                <button onclick="if (confirm('¿Estás seguro de que deseas eliminar este usuario?')) { window.location.href='gestionUsuarios.php?eliminar=<?php echo $usuario['id']; ?>'; }" class="delete-button">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </main>
    </div>
</body>
</html>
