<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio Sesión</title>
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
</head>
<body>
    <div class="form-container">
        <h1>Iniciar Sesión</h1>
        <a href="/index.php" class="header-link">Volver a inicio</a>

        <!-- Formulario de inicio de sesión -->
        <form id="formInicioSesion" name="inicio_sesion" action="../Controlador/loginControlador.php" method="post" class="login-form">
            <div class="form-group">
                <label for="usuario">Usuario:</label>
                <input type="text" name="usuario" id="usuario" 
                    value="<?php echo isset($_POST['usuario']) ? htmlspecialchars($_POST['usuario']) : ''; ?>" 
                    required>
            </div>
            <div class="form-group">
                <label for="contrasena">Contraseña:</label>
                <input type="password" name="contrasena" id="contrasena" required>
            </div>
            <!-- Botón para mostrar la contraseña -->
            <button type="button" class="submit-button" onclick="mostrarContraseña()">Mostrar Contraseña</button>
            <!-- Botón para enviar el formulario -->
            <input type="submit" class="submit-button" name="inicio_sesion" value="Iniciar Sesión">
        </form>

        <!-- Contenedor para mostrar errores de inicio de sesión -->
        <div id="error-container">
            <?php
            session_start();
            $mostrarBotonCambio = false; // Variable para decidir si mostramos el botón "Cambiar Contraseña"

            if (isset($_SESSION['errores']) && !empty($_SESSION['errores'])) {
                foreach ($_SESSION['errores'] as $error) {
                    echo "<p class='error-message'>" . htmlspecialchars($error) . "</p>";

                    // Verificar si el error es "Contraseña incorrecta"
                    if (strpos($error, "❌ Contraseña incorrecta") !== false) {
                        $mostrarBotonCambio = true; // Activamos el botón si este error aparece
                    }
                }
                unset($_SESSION['errores']);
            }
            ?>
        </div>

        <!-- Mostrar botón de cambiar contraseña solo si la contraseña es incorrecta -->
        <?php if ($mostrarBotonCambio): ?>
            <div id="cambiar-contrasena-container" style="margin-top: 20px;">
                <button type="button" id="btnCambiarContrasena" class="submit-button" onclick="mostrarFormularioCambio()">Cambiar Contraseña</button>
            </div>
        <?php endif; ?>

        <!-- Formulario de cambio de contraseña (oculto inicialmente) -->
        <form id="formCambioContrasena" name="cambio_contrasena" action="../Controlador/loginControlador.php" method="post" class="login-form" style="display: none; margin-top: 20px;">
            <div class="form-group">
                <label for="usuario_cambio">Usuario:</label>
                <input type="text" name="usuario_cambio" id="usuario_cambio" required>
            </div>
            <div class="form-group">
                <label for="nueva_contrasena">Nueva Contraseña:</label>
                <input type="password" name="nueva_contrasena" id="nueva_contrasena" required>
            </div>
            <div class="form-group">
                <label for="confirmar_contrasena">Confirmar Contraseña:</label>
                <input type="password" name="confirmar_contrasena" id="confirmar_contrasena" required>
            </div>
            <!-- Botón para enviar el formulario -->
            <input type="submit" class="submit-button" name="cambiar_contrasena" value="Cambiar Contraseña">
        </form>
    </div>

    <!-- Script para mostrar u ocultar elementos -->
    <script>
        function mostrarContraseña() {
            let contrasenaInput = document.getElementById("contrasena");
            contrasenaInput.type = contrasenaInput.type === "password" ? "text" : "password";
        }

        function mostrarFormularioCambio() {
            let formCambio = document.getElementById("formCambioContrasena");
            let btnCambiarContrasena = document.getElementById("btnCambiarContrasena");

            // Cambiar entre mostrar y ocultar el formulario
            if (formCambio.style.display === "none") {
                formCambio.style.display = "block";
                btnCambiarContrasena.textContent = "Cancelar Cambio de Contraseña";
            } else {
                formCambio.style.display = "none";
                btnCambiarContrasena.textContent = "Cambiar Contraseña";
            }
        }
    </script>
</body>
</html>
