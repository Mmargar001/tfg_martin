<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
// Verificar que el usuario esté autenticado y sea administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'cliente') {
    header('Location: ../Vista/login.php');
    exit();
}
?> 
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nosotros</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fef6e4;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
        }

        .about-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            background-color: #ffcb77;
            padding: 20px;
            border-bottom: 4px solid #d4a373;
        }

        .header h1 {
            margin: 0;
            color: #333;
        }

        .main-content {
            padding: 20px;
        }

        .about-section {
            margin-bottom: 30px;
        }

        .about-section h2 {
            font-size: 1.8em;
            color: #333;
            margin-bottom: 10px;
        }

        .about-section p {
            margin: 10px 0;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="about-container">
        <header class="header">
            <h1>Sobre Nosotros</h1>
        </header>
        <main class="main-content">
            <section class="about-section">
                <h2>Nuestra Historia</h2>
                <p>Somos una empresa dedicada a diseñar itinerarios de actividades personalizados para nuestros clientes, haciendo que cada día sea especial y único. Fundada en 2024, nuestra misión es eliminar la carga de planificar unas vacaciones o un día libre, permitiéndote disfrutar sin preocupaciones. Nos enfocamos en crear experiencias memorables, asegurándonos de que cada detalle esté perfectamente organizado para tu comodidad y disfrute. Nuestro rápido crecimiento se debe a nuestro compromiso con la calidad y la excelencia en el diseño de itinerarios, garantizando que cada experiencia sea excepcional y completamente adaptada a tus necesidades.</p>
            </section>
            <section class="about-section">
                <h2>Nuestro Equipo</h2>
                <p>Contamos con un equipo de profesionales apasionados por los viajes y el turismo, dedicados a ayudar a nuestros clientes a crear recuerdos inolvidables.</p>
            </section>
            <section class="about-section">
                <h2>Nuestra Misión</h2>
                <p>Nuestro objetivo es hacer que cada día sea único y especial, ofreciéndote itinerarios personalizados para que solo tengas que preocuparte por disfrutar al máximo, ya sea en tu ciudad o en cualquier destino.</p>
            </section>
        </main>
    </div>
</body>
</html>
