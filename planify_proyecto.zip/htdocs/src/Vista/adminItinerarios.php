<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
// Verifica que el usuario esté autenticado y tenga el rol de administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'administrador') {
    // Redirige a la página de inicio de sesión si el usuario no está autenticado o no es administrador
    header('Location: ../Vista/login.php');
    
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Itinerarios</title>
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
</head>
<body>
    <div class="admin-container">
        <header class="header">
            <h1>Gestión de Itinerarios</h1>
            <a href="inicioAdmin.php" class="a">Volver al área de administración</a>
        </header>
        
        <main class="main-content">
            <!-- Sección de filtro de itinerarios -->
            <section class="filter-section">
                <form class="filter-form">
                    <input type="text" placeholder="Buscar itinerario..." />
                    <button type="submit" class="filter-button">Buscar</button>
                </form>
            </section>

            <section class="itineraries-list">
                <table class="itineraries-table">
                    <thead>
                        <tr>
                            <!-- Encabezados de la tabla -->
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Usuario</th>
                            <th>Fecha de Creación</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Itinerario 1</td>
                            <td>Descripción del itinerario 1</td>
                            <td>Usuario 1</td>
                            <td>2024-08-01</td>
                            <td>
                                <!-- Botones de acción para ver, editar o eliminar itinerario -->
                                <button onclick="window.location.href='verItinerario.php?id=1'" class="button">Ver</button>
                                <button onclick="window.location.href='editarItinerario.php?id=1'" class="button">Editar</button>
                                <form method="post" action="eliminarItinerario.php" class="delete-form" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este itinerario?');">
                                    <input type="hidden" name="itinerario_id" value="1">
                                    <button type="submit" name="eliminar_itinerario" class="delete-button">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </section>
        </main>
        
        <footer class="footer">
            <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
        </footer>
    </div>
</body>
</html>
