<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Actividades;  
use proyecto\Modelo\Comentarios;

// Verifica si el usuario es cliente
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    // Redirige a la página de inicio de sesión si el usuario no es cliente
    header("Location: ../Vista/login.php");
    exit();
}

// Obtiene el ID de la actividad desde la URL
$actividad_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Obtiene los detalles de la actividad
$actividad = Actividades::obtenerActividadPorId($actividad_id);
if (!$actividad) {
    echo "Actividad no encontrada.";
    exit();
}

// Obtiene los comentarios de la actividad
$comentarios = Comentarios::obtenerComentariosPorActividad($actividad_id);
$puntuacionPromedio = Comentarios::obtenerPuntuacionPromedio($actividad_id);

// Muestra solo los primeros 3 comentarios
$comentariosMostrados = array_slice($comentarios, 0, 3);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comentarios de Actividad</title>
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
</head>
<body>
    <div class="client-container">
        <header class="header">
            <h1><?php echo htmlspecialchars($actividad['titulo']); ?></h1>
            <a href="inicioCliente.php" class="back-button">Volver al Inicio</a>
        </header>
        <main class="main-content">
            <!-- Sección de detalles de la actividad -->
            <section class="product-details">
                <div class="product-image">
                    <!-- Espacio para una imagen de la actividad -->
                </div>
                <div class="product-info">
                    <h2><?php echo htmlspecialchars($actividad['titulo']); ?></h2>
                    <p><strong>Descripción:</strong> <?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                    <p><strong>Duración:</strong> <?php echo htmlspecialchars($actividad['duracion']); ?> horas</p>
                    <p><strong>Ubicación:</strong> <?php echo htmlspecialchars($actividad['ubicacion']); ?></p>
                    <p><strong>Precio:</strong> <?php echo htmlspecialchars($actividad['precio']); ?> €</p>
                    <p><strong>Categoría:</strong> <?php echo htmlspecialchars($actividad['categoria']); ?></p>
                    <p><strong>Puntuación media:</strong> <?php echo number_format($puntuacionPromedio, 1); ?> / 5</p>
                </div>
            </section>

            <!-- Sección de comentarios -->
            <section class="comments-section">
                <h3>Comentarios de Usuarios</h3>
                <?php if (empty($comentarios)): ?>
                    <p>No hay comentarios para esta actividad.</p>
                <?php else: ?>
                    <?php foreach ($comentariosMostrados as $comentario): ?>
                        <div class="comment">
                            <p><strong><?php echo htmlspecialchars($comentario['usuario']); ?>:</strong> <?php echo htmlspecialchars($comentario['comentario']); ?></p>
                            <p>Puntuación: <?php echo htmlspecialchars($comentario['puntuacion']); ?> / 5</p>
                            <p>Fecha: <?php echo htmlspecialchars($comentario['fecha']); ?></p>
                        </div>
                    <?php endforeach; ?>

                    <!-- Mostrar botón para ver todos los comentarios si hay más de 3 -->
                    <?php if (count($comentarios) > 3): ?>
                        <a href="todosComentariosActividad.php?id=<?php echo htmlspecialchars($actividad['id']); ?>" class="view-all-comments-button">Ver Todos los Comentarios</a>
                    <?php endif; ?>
                <?php endif; ?>
            </section>

            <!-- Sección para agregar un comentario -->
            <section class="add-comment-section">
                <h3>Deja tu Comentario</h3>
                <form action="../Controlador/operacionesComentarios.php" method="post">
                    <input type="hidden" name="actividad_id" value="<?php echo htmlspecialchars($actividad['id']); ?>">
                    <textarea name="comentario" placeholder="Escribe tu comentario aquí..." required></textarea>
                    <select name="puntuacion" required>
                        <option value="">Puntuación</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                    <button type="submit" name="agregar_comentario" class="button">Enviar Comentario</button>
                </form>
            </section>

            
        </main>
        <footer class="footer">
            <div class="footer-container">
                <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
            </div>
        </footer>
    </div>
</body>
</html>
