<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayuda y Recursos</title>
    <link rel="stylesheet" href="../Estilos/estilosComunes.css">
    <style>
        /* Estilos para la página de Ayuda y Recursos */
        .client-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background-color: #ffcb77; /* Color del encabezado */
            padding: 20px;
            border-bottom: 4px solid #d4a373;
            text-align: center;
        }

        .header h1 {
            margin: 0;
            color: #333;
            font-size: 2em;
        }

        .help-section {
            margin: 30px 0; /* Espaciado entre secciones */
            padding: 20px;
            background-color: #ffffff; /* Fondo blanco para secciones */
            border-radius: 10px; /* Bordes redondeados */
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); /* Sombra */
        }

        .help-section h2 {
            font-size: 1.8em;
            color: #333;
        }

        .faq-list,
        .resource-list {
            list-style: none; /* Sin puntos */
            padding: 0; /* Sin relleno */
            margin: 0; /* Sin margen */
        }

        .faq-list li,
        .resource-list li {
            margin: 10px 0; /* Espacio entre ítems */
        }

        .faq-list a,
        .resource-list a {
            text-decoration: none; /* Sin subrayado */
            color: #f4a261; /* Color de los enlaces */
            transition: color 0.3s; /* Transición suave */
        }

        .faq-list a:hover,
        .resource-list a:hover {
            color: #e76f51; /* Color al pasar el mouse */
        }

        .search-section {
            display: flex;
            flex-direction: column; /* Colocar elementos en columna */
        }

        .search-input {
            padding: 10px; /* Relleno */
            border: 1px solid #ccc; /* Borde ligero */
            border-radius: 5px; /* Bordes redondeados */
            margin: 10px 0; /* Espaciado */
        }

        /* Estilo de los mensajes de ayuda */
        .faq-content h3 {
            color: #333; /* Color de los títulos de preguntas */
            font-size: 1.6em; /* Tamaño de fuente */
            margin: 15px 0; /* Margen para separación */
        }

        .faq-content p {
            margin-bottom: 15px; /* Margen en párrafos */
        }
    </style>
</head>
<body>
    <div class="client-container">
        <header class="header">
            <h1>Ayuda y Recursos</h1>
            <nav>
                <a href="inicioCliente.php" >Volver al área del cliente</a>
            </nav>
        </header>
        <main>
            <section class="help-section">
                <h2>Preguntas Frecuentes</h2>
                <ul class="faq-list">
                    <li><a href="#pregunta1">¿Cómo crear un itinerario?</a></li>
                    <li><a href="#pregunta2">¿Cómo gestionar mis itinerarios?</a></li>
                    <li><a href="#pregunta3">¿Cómo realizar un pago?</a></li>
                </ul>
                <div class="faq-content">
                    <h3 id="pregunta1">¿Cómo crear un itinerario?</h3>
                    <p>Para crear un itinerario, dirígete a la sección de "Crear Itinerario" en el menú principal. Completa los detalles necesarios y guarda tu itinerario.</p>

                    <h3 id="pregunta2">¿Cómo gestionar mis itinerarios?</h3>
                    <p>Ve a la sección "Mis Itinerarios" para ver, editar o eliminar tus itinerarios existentes.</p>

                    <h3 id="pregunta3">¿Cómo realizar un pago?</h3>
                    <p>Para realizar un pago, ve a la página del itinerario que deseas pagar y haz clic en el botón "Pagar Itinerario". Sigue las instrucciones para completar el pago.</p>
                </div>
            </section>

            <section class="help-section">
                <h2>Recursos Adicionales</h2>
                <ul class="resource-list">
                    <li><a href="contacto.php">Contacto</a></li>
                    <li><a href="terminos.php">Términos de Servicio</a></li>
                    <li><a href="privacidad.php">Política de Privacidad</a></li>
                </ul>
            </section>

            <section class="help-section search-section">
                <h2>Buscar en Ayuda</h2>
                <input type="text" id="search" placeholder="Buscar..." class="search-input">
            </section>
        </main>
    </div>

    <script>
        // Función para buscar en el contenido de ayuda
        document.getElementById('search').addEventListener('input', function() {
            let query = this.value.toLowerCase();
            let helpSections = document.querySelectorAll('.faq-content h3');
            helpSections.forEach(function(section) {
                if (section.textContent.toLowerCase().includes(query)) {
                    section.style.display = '';
                    section.nextElementSibling.style.display = ''; // Mostrar el contenido relacionado
                } else {
                    section.style.display = 'none';
                    section.nextElementSibling.style.display = 'none'; // Ocultar el contenido relacionado
                }
            });
        });
    </script>
</body>
</html>
