<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
// Verificar que el usuario esté autenticado y sea administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'cliente') {
    header('Location: ../Vista/login.php');
    exit();
}
?>  
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Términos de Servicio</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fef6e4;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            background-color: #ffcb77;
            padding: 20px;
            border-bottom: 4px solid #d4a373;
        }

        .header h1 {
            margin: 0;
            color: #333;
        }

        .main-content {
            padding: 20px;
        }

        .main-content h2 {
            font-size: 1.8em;
            color: #333;
            margin-top: 30px;
        }

        .main-content p {
            margin: 10px 0;
            color: #666;
        }

        /* Footer */
        .footer {
            background-color: #ffcb77;
            padding: 40px 20px;
            margin-top: 40px;
            text-align: center;
            border-top: 4px solid #d4a373;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }

        .footer-column {
            max-width: 300px;
        }

        .footer-column h3 {
            color: #333;
            font-size: 1.6em;
            margin-bottom: 10px;
        }

        .footer-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-link {
            text-decoration: none;
            color: #333;
            display: block;
            margin: 5px 0;
            transition: color 0.3s;
        }

        .footer-link:hover {
            color: #e76f51;
        }

        .footer-bottom {
            margin-top: 20px;
            font-size: 0.9em;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Términos de Servicio</h1>
        </header>
        <main class="main-content">
            <h2>Introducción</h2>
            <p>Estos términos de servicio ("Términos") rigen tu acceso y uso de nuestros servicios. Al utilizar nuestros servicios, aceptas cumplir con estos Términos.</p>
            
            <h2>Uso de Nuestros Servicios</h2>
            <p>Debes seguir cualquier política que se te ponga a disposición dentro de los servicios. No debes hacer un mal uso de nuestros servicios.</p>
            
            <h2>Cuenta de Usuario</h2>
            <p>Para utilizar ciertos servicios, debes crear una cuenta. Eres responsable de la actividad que ocurra en tu cuenta y debes mantener la contraseña de tu cuenta segura.</p>
            
            <h2>Modificaciones</h2>
            <p>Podemos modificar estos Términos en cualquier momento. Te notificaremos sobre los cambios en los Términos en la medida de lo posible.</p>
            
            <h2>Terminación</h2>
            <p>Puedes dejar de utilizar nuestros servicios en cualquier momento. Nos reservamos el derecho de suspender o dar por terminado tu acceso a los servicios si incumples estos Términos o si creemos razonablemente que es necesario hacerlo por motivos de seguridad.</p>
            
            <h2>Limitación de Responsabilidad</h2>
            <p>Nos esforzamos por mantener nuestros servicios disponibles, precisos, seguros y libres de errores, pero no podemos garantizarlo. En la medida permitida por la ley, no seremos responsables por cualquier pérdida o daño que puedas sufrir como resultado del uso de nuestros servicios.</p>
            
            <h2>Legislación Aplicable</h2>
            <p>Estos Términos se rigen por las leyes del Estado de [tu estado o país], sin tener en cuenta sus disposiciones sobre conflictos de leyes.</p>
        </main>
    </div>
   
</body>
</html>
