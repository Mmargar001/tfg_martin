<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    <style>
        /* Estilos para la barra de seguridad */
        .password-strength-container {
            margin-top: 10px;
            width: 100%;
            height: 5px;
            border-radius: 5px;
            background-color: #ddd;
        }
        .password-strength-bar {
            height: 100%;
            width: 0;
            border-radius: 5px;
            transition: width 0.5s ease;
        }
        /* Colores según el nivel de seguridad */
        .low-security {
            background-color: #e74c3c; /* Rojo */
        }
        .medium-security {
            background-color: #f39c12; /* Naranja */
        }
        .high-security {
            background-color: #2ecc71; /* Verde */
        }
        /* Estilo para mensajes de error */
        .error-message {
            color: #e74c3c;
            font-size: 18px;
            font-weight: bold;
        }
        /* Estilo para mensajes de seguridad */
        .security-message {
            font-size: 14px;
            color: #000;
            margin-top: 5px;
        }
        /* Estilo para los mensajes de seguridad en verde */
        .high-security-message {
            color: #2ecc71;
            font-size: 16px;
        }
        /* Estilo para los mensajes de seguridad en naranja (media seguridad) */
        .medium-security-message {
            color: #f39c12;
            font-size: 14px;
        }
        /* Estilo para los mensajes de seguridad en rojo (baja seguridad) */
        .low-security-message {
            color: #e74c3c;
            font-size: 14px;
        }
        /* Estilo para mejorar la legibilidad */
        .password-improvement-message {
            font-size: 12px;
            color: #000;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="form-container register-container">
        <h1>Registro</h1>
       <a href="/index.php" class="header-link">Volver a incio </a>
        <?php
        session_start();
        require_once __DIR__ . '/../../vendor/autoload.php';
        // Muestra los mensajes de error si existen
        if (isset($_SESSION['errores']) && !empty($_SESSION['errores'])) {
            foreach ($_SESSION['errores'] as $error) {
                echo "<div class='error-message'>{$error}</div>";
            }
            unset($_SESSION['errores']);
        }

        // Muestra el mensaje de éxito si existe
        if (isset($_SESSION['mensaje_exito'])) {
            echo "<div class='success-message'>{$_SESSION['mensaje_exito']}</div>";
            unset($_SESSION['mensaje_exito']);
        }
        ?>
        
        <!-- Formulario de registro de usuario -->
        <form action="../Controlador/registroControlador.php" method="post">
            <!-- Campo para el nombre de usuario -->
            <label for="usuario">Usuario:</label>
            <input type="text" name="usuario" required>

            <!-- Campo para la contraseña -->
            <label for="contrasena">Contraseña:</label><br>
            <input type="password" name="contrasena" id="contrasena" required><br>

            <!-- Barra de seguridad -->
            <div class="password-strength-container">
                <div id="strength-bar" class="password-strength-bar"></div>
            </div>
            <div id="password-strength-message" class="security-message"></div>
            <div id="password-improvement-message" class="password-improvement-message"></div>

            <!-- Campo para confirmar la contraseña -->
            <label for="confirmar_contrasena">Confirmar Contraseña:</label><br>
            <input type="password" name="confirmar_contrasena" id="confirmar_contrasena" required><br>
            <div id="password-mismatch-message" class="error-message" style="display: none;">❌ Las contraseñas no coinciden.</div>

            <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'administrador'): ?>
                <!-- Campo para seleccionar el tipo de usuario solo visible para administradores -->
                <label for="tipo_usuario">Tipo de Usuario:</label>
                <select name="tipo_usuario" id="tipo_usuario" required>
                    <option value="cliente">Cliente</option>
                    <option value="administrador">Administrador</option>
                </select>
            <?php else: ?>
                <!-- Campo oculto para tipo de usuario, asignado como 'cliente' por defecto -->
                <input type="hidden" name="tipo_usuario" value="cliente">
            <?php endif; ?>

            <!-- Botón para enviar el formulario de registro -->
            <input type="submit" class="submit-button" name="registro" value="Registrarse">
        </form>
    </div>

    <script>
        // Función que evalúa la seguridad de la contraseña
        function evaluatePasswordStrength(password) {
            let strengthBar = document.getElementById("strength-bar");
            let message = document.getElementById("password-strength-message");
            let improvementMessage = document.getElementById("password-improvement-message");
            let score = 0;
            let strength = '';
            let missingCriteria = [];

            // Criterios para seguridad de la contraseña
            let hasLowerCase = /[a-z]/.test(password);
            let hasUpperCase = /[A-Z]/.test(password);
            let hasNumbers = /\d/.test(password);
            let hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);
            let isLongEnough = password.length >= 5;

            // Evaluar el puntaje
            if (password.length < 5 || /^[a-z]+$/.test(password) || /^\d+$/.test(password)) {
                // Contraseña inválida si tiene solo letras o solo números o es menor de 5 caracteres
                strengthBar.style.width = '0%';
                strengthBar.className = 'password-strength-bar low-security';
                message.innerHTML = 'Contraseña inválida. Debe tener al menos 5 caracteres y combinar letras y números.';
                message.className = 'error-message'; // Aplica el estilo de mensaje de error
                return;
            }

            if (isLongEnough) score += 1;
            if (hasLowerCase) score += 1;
            if (hasUpperCase) score += 1;
            if (hasNumbers) score += 1;
            if (hasSpecialChars) score += 1;

            // Establecer el color de la barra de seguridad según el puntaje
            if (score <= 2) {
                strength = 'Baja';
                strengthBar.className = 'password-strength-bar low-security';
                message.innerHTML = 'La contraseña es poco segura.';
                message.className = 'low-security-message'; // Estilo de baja seguridad
                missingCriteria = ['Una longitud mínima de 5 caracteres', 'Al menos una letra mayúscula', 'Un número', 'Un carácter especial'];
            } else if (score == 3) {
                strength = 'Media';
                strengthBar.className = 'password-strength-bar medium-security';
                message.innerHTML = 'La contraseña tiene seguridad media.';
                message.className = 'medium-security-message'; // Estilo de seguridad media
                missingCriteria = ['Un carácter especial', 'Una letra mayúscula'];
            } else {
                strength = 'Alta';
                strengthBar.className = 'password-strength-bar high-security';
                message.innerHTML = 'La contraseña es muy segura.';
                message.className = 'high-security-message'; // Estilo de alta seguridad
                missingCriteria = []; // Ya no faltan criterios
            }

            // Ajustar el ancho de la barra de seguridad
            strengthBar.style.width = (score * 20) + '%';

            // Mostrar los criterios que faltan para mejorar la seguridad
            if (missingCriteria.length > 0) {
                improvementMessage.innerHTML = 'Para mejorar la seguridad, faltan: ' + missingCriteria.join(', ') + '.';
            } else {
                improvementMessage.innerHTML = ''; // No falta nada para mejorar la seguridad
            }
        }

        // Validar que las contraseñas coinciden en tiempo real
        function validatePasswordsMatch() {
            let password = document.getElementById("contrasena").value;
            let confirmPassword = document.getElementById("confirmar_contrasena").value;
            let mismatchMessage = document.getElementById("password-mismatch-message");

            if (password !== confirmPassword) {
                mismatchMessage.style.display = 'block';  // Mostrar mensaje si no coinciden
            } else {
                mismatchMessage.style.display = 'none';   // Ocultar mensaje si coinciden
            }
        }

        // Añadir eventos para la contraseña y su confirmación
        document.getElementById('contrasena').addEventListener('input', function() {
            evaluatePasswordStrength(this.value);
            validatePasswordsMatch();
        });

        document.getElementById('confirmar_contrasena').addEventListener('input', function() {
            validatePasswordsMatch();
        });
    </script>
</body>
</html>
