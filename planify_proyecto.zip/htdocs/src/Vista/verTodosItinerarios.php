<?php
// Iniciar sesión para acceder a las variables de sesión
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
// Verificar que el usuario esté autenticado y tenga el rol de 'cliente'
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'cliente') {
    // Redirigir al usuario a la página de login si no está autenticado o no es un cliente
    header('Location: ../Vista/login.php');
    
}

// Incluir el modelo de Itinerarios
require_once '../Modelo/Itinerarios.php';

// Obtener el ID del usuario desde la sesión
$usuario = $_SESSION['usuario_id'];

// Obtener los itinerarios del usuario desde el modelo
$itinerarios = Itinerarios::obtenerItinerariosPorUsuario($usuario);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todos Mis Itinerarios</title>
    <!-- Incluir hojas de estilo para el diseño -->
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
</head>
<body>
    <div class="client-container">
        <header class="header">
            <?php
            // Mostrar el nombre del usuario en el encabezado
            if (isset($_SESSION['usuario'])) {
                echo "<h1 class='welcome-message'>Bienvenido, {$_SESSION['usuario']}</h1>";
            } else {
                // Redirigir a la página de inicio si el usuario no está autenticado
                header('Location: ../inicio.php');
                
            }
            ?>
            <nav class="header-nav">
                <!-- Enlaces para volver a la página de login o al inicio -->
                <a href="login.php" class="header-link">Volver al Login</a>
                <a href="index.php" class="header-link">Volver al Inicio</a>
            </nav>
        </header>
        <nav class="nav">
            <ul class="nav-list">
                <!-- Enlaces para crear un itinerario o ver el perfil del cliente -->
                <li class="nav-item"><a href="crearItinerario.php" class="nav-link">Crear Itinerario</a></li>
                <li class="nav-item"><a href="perfilCliente.php" class="nav-link">Mi Perfil</a></li>
            </ul>
        </nav>
        <main class="main-content">
            <section class="section">
                <h2 class="section-title">Todos Mis Itinerarios</h2>
                <?php if (empty($itinerarios)): ?>
                    <!-- Mensaje si no hay itinerarios creados -->
                    <p>No tienes itinerarios creados.</p>
                <?php else: ?>
                    <?php foreach ($itinerarios as $itinerario): ?>
                        <div class="card">
                            <div class="card-header">
                                <h3><?php echo htmlspecialchars($itinerario['nombre']); ?></h3>
                            </div>
                            <div class="card-content">
                                <p><?php echo htmlspecialchars($itinerario['descripcion']); ?></p>
                                <!-- Enlace para ver más detalles o agregar actividades al itinerario -->
                                <a href="gestionItinerarios.php?id=<?php echo $itinerario['id']; ?>" class="card-link secondary">Ver Más / Agregar Actividades</a>
                                <!-- Formulario para eliminar un itinerario -->
                                <form method="post" action="../Controlador/operacionesItinerario.php" class="delete-form" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este itinerario?');">
                                    <input type="hidden" name="itinerario_id" value="<?php echo $itinerario['id']; ?>">
                                    <button type="submit" name="eliminar_itinerario" class="card-link danger">Eliminar Itinerario</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
        </main>
        <footer class="footer">
            <div class="footer-container">
                <!-- Sección de enlaces útiles -->
                <div class="footer-column">
                    <h3>Enlaces Útiles</h3>
                    <ul class="footer-list">
                        <li><a href="nosotros.php" class="footer-link">Sobre Nosotros</a></li>
                        <li><a href="contacto.php" class="footer-link">Contacto</a></li>
                        <li><a href="privacidad.php" class="footer-link">Política de Privacidad</a></li>
                        <li><a href="terminos.php" class="footer-link">Términos de Servicio</a></li>
                    </ul>
                </div>
                <!-- Sección de redes sociales -->
                <div class="footer-column">
                    <h3>Síguenos</h3>
                    <ul class="footer-list">
                        <li><a href="#" class="footer-link">Facebook</a></li>
                        <li><a href="#" class="footer-link">Twitter</a></li>
                        <li><a href="#" class="footer-link">Instagram</a></li>
                        <li><a href="#" class="footer-link">LinkedIn</a></li>
                    </ul>
                </div>
                <!-- Sección de contacto -->
                <div class="footer-column">
                    <h3>Contacto</h3>
                    <p>Email: soporte@example.com</p>
                    <p>Teléfono: +1 234 567 890</p>
                </div>
            </div>
            <!-- Pie de página -->
            <div class="footer-bottom">
                <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
            </div>
        </footer>
    </div>
</body>
</html>
