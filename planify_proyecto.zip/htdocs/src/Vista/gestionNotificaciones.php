<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Usuarios;
use proyecto\Modelo\Notificaciones;

// Verificar que el usuario esté autenticado y sea administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'administrador') {
    header('Location: ../Vista/login.php');
}

// Mostrar mensajes de éxito o error
if (isset($_GET['success'])) {
    echo "<p class='success-message'>" . htmlspecialchars($_GET['success']) . "</p>";
} elseif (isset($_GET['error'])) {
    echo "<p class='error-message'>" . htmlspecialchars($_GET['error']) . "</p>";
}

// Obtener todos los usuarios (clientes)
$usuarios = Usuarios::obtenerUsuarios();
$clientes = array_filter($usuarios, function($usuario) {
    return $usuario['tipo'] === 'cliente';
});

// Filtrar notificaciones si hay parámetros
$filtro_usuario_id = isset($_GET['usuario_id']) ? intval($_GET['usuario_id']) : null;
$filtro_fecha = isset($_GET['fecha']) ? $_GET['fecha'] : null;

$notificaciones = Notificaciones::obtenerNotificacionesFiltradas($filtro_usuario_id, $filtro_fecha);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    <title>Gestión de Notificaciones</title>
</head>
<body>
    <div class="admin-container">
        <header class="header">
            <h1>Gestión de Notificaciones</h1>
            <a href="inicioAdmin.php" class="a">Volver al área de administración</a>
        </header>
        
        <main class="main-content">
            <!-- Crear Notificación -->
            <section>
                <h2>Crear Notificación</h2>
                <form method="post" action="../Controlador/notificacionesController.php">
                    <label for="mensaje">Mensaje:</label>
                    <textarea id="mensaje" name="mensaje" rows="4" required></textarea>
                    
                    <label for="usuario_id">Selecciona un Usuario:</label>
                    <select id="usuario_id" name="usuario_id" required>
                        <option value="">-- Selecciona un Usuario --</option>
                        <?php foreach ($clientes as $cliente): ?>
                            <option value="<?= htmlspecialchars($cliente['id']) ?>">
                                <?= htmlspecialchars($cliente['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <button type="submit" name="crear_notificacion">Crear</button>
                </form>
            </section>

            <!-- Filtrar Notificaciones -->
            <section>
                <h2>Filtrar Notificaciones</h2>
                <form method="get" action="">
                    <label for="fecha">Fecha:</label>
                    <input type="date" id="fecha" name="fecha" value="<?= htmlspecialchars($filtro_fecha ?? '') ?>">
                    
                    <label for="usuario_id">Usuario:</label>
                    <select id="usuario_id" name="usuario_id">
                        <option value="">-- Todos los Usuarios --</option>
                        <?php foreach ($clientes as $cliente): ?>
                            <option value="<?= htmlspecialchars($cliente['id']) ?>" <?= ($filtro_usuario_id === $cliente['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cliente['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <button type="submit">Aplicar Filtro</button>
                </form>
            </section>

            <!-- Mostrar Notificaciones -->
            <section>
                <h2>Lista de Notificaciones</h2>
                <?php if (empty($notificaciones)): ?>
                    <p>No hay notificaciones disponibles.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Mensaje</th>
                                <th>Usuario</th>
                                <th>Fecha</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($notificaciones as $notificacion): ?>
                                <tr>
                                    <td><?= htmlspecialchars($notificacion['mensaje']) ?></td>
                                    <td><?= htmlspecialchars($notificacion['usuario_nombre']) ?></td>
                                    <td><?= htmlspecialchars($notificacion['fecha']) ?></td>
                                    <td>
                                        <form method="post" action="../Controlador/notificacionesController.php" style="display:inline;">
                                            <input type="hidden" name="notificacion_id" value="<?= htmlspecialchars($notificacion['id']) ?>">
                                            <button type="submit" name="eliminar_notificacion">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>
        </main>

        <footer>
            <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
        </footer>
    </div>
</body>
</html>
