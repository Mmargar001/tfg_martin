<?php 
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Actividades;  
use proyecto\Modelo\Categorias;
// Verificar si el usuario es administrador
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador')
{
    header("Location: ../Vista/login.php");
    
}

// Obtener todas las categorías para mostrarlas en el formulario
$categorias = Categorias::obtenerCategorias();

// Obtener todas las actividades
$actividades = Actividades::obtenerActividades();
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gestión de Actividades</title>
        <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
        <style>
            /* Estilo para ocultar el formulario inicialmente */
            #actividad-form-container {
                display: none;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <header class="header">
                <h1>Gestión de Actividades</h1>
                <a href="inicioAdmin.php" class="a">Volver al área de administración</a>
            </header>
            <main class="main-content">
                <!-- Botón para mostrar el formulario de agregar actividad -->
                <button onclick="mostrarFormulario()" class="create-button">Agregar Actividad</button>

                <div id="actividad-form-container">
                    <h2 id="form-title">Crear Actividad</h2>
                    <!-- Formulario para agregar o editar actividades -->
                    <form id="actividad-form" method="post" action="../Controlador/operacionesActividades.php" onsubmit="ocultarFormulario()">
                        <input type="hidden" id="actividad-id" name="id">
                        <div class="form-group">
                            <label for="titulo">Título:</label>
                            <input type="text" id="titulo" name="titulo" required>
                        </div>
                        <div class="form-group">
                            <label for="descripcion">Descripción:</label>
                            <input type="text" id="descripcion" name="descripcion" required>
                        </div>
                        <div class="form-group">
                            <label for="duracion">Duración:</label>
                            <input 
                                type="text" 
                                id="duracion" 
                                name="duracion" 
                                pattern="\d{1,2}(\.\d{1,2})?[smh]" 
                                title="Introduce hasta dos números enteros o decimales seguidos de 's' (segundos), 'm' (minutos), o 'h' (horas). Ejemplo: 15.5m, 2h" 
                                required
                                >
                        </div>
                        <div class="form-group">
                            <label for="ubicacion">Ubicación:</label>
                            <input type="text" id="ubicacion" name="ubicacion" required>
                        </div>
                        <div class="form-group">
                            <label for="precio">Precio:</label>
                            <input type="text" id="precio" name="precio" required>
                        </div>
                        <div class="form-group">
                            <label for="categoria">Categoría:</label>
                            <select id="categoria" name="categoria" required>
                                    <?php foreach ($categorias as $categoria): ?>
                                    <option value="<?php echo htmlspecialchars($categoria['id']); ?>">
                                    <?php echo htmlspecialchars($categoria['nombre']); ?>
                                    </option>
<?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="fecha">Fecha:</label>
                            <input type="date" id="fecha" name="fecha" required>
                        </div>
                        <div class="form-group">
                            <label for="hora">Hora:</label>
                            <input type="time" id="hora" name="hora" required>
                        </div>
                        <button type="submit" class="submit-button">Guardar</button>
                    </form>
                </div>

                <!-- Sección de lista de actividades -->
                <section class="activity-list">
                    <h2>Lista de Actividades</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Título</th>
                                <th>Descripción</th>
                                <th>Duración</th>
                                <th>Ubicación</th>
                                <th>Precio</th>
                                <th>Categoría</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
<?php foreach ($actividades as $actividad): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($actividad['id']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['titulo']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['descripcion']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['duracion']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['ubicacion']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['precio']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['categoria']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['fecha']); ?></td>
                                    <td><?php echo htmlspecialchars($actividad['hora']); ?></td>
                                    <td>
                                        <!-- Botones para editar y eliminar la actividad -->
                                        <button onclick="editarActividad(<?php echo htmlspecialchars(json_encode($actividad)); ?>)" class="button">Editar</button>

                                        <form method="post" action="../Controlador/operacionesActividades.php" style="display:inline;">
                                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($actividad['id']); ?>">
                                            <button type="submit" name="eliminar_actividad" class="delete-button" onclick="return confirm('¿Estás seguro de que deseas eliminar esta actividad?');">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
<?php endforeach; ?>
                        </tbody>
                    </table>
                </section>
            </main>
            <footer class="footer">
                <div class="footer-container">
                    <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
                </div>
            </footer>
        </div>

        <script>
            // Función para mostrar el formulario de agregar actividad
            function mostrarFormulario() {
                document.getElementById('actividad-form-container').style.display = 'block';
                document.getElementById('form-title').textContent = 'Crear Actividad';
                document.getElementById('actividad-form').reset();
            }

            // Función para ocultar el formulario después de enviarlo
            function ocultarFormulario() {
                document.getElementById('actividad-form-container').style.display = 'none';
            }

            // Función para llenar el formulario con los datos de la actividad seleccionada para editar
            function editarActividad(actividad) {
                document.getElementById('actividad-id').value = actividad.id;
                document.getElementById('titulo').value = actividad.titulo;
                document.getElementById('descripcion').value = actividad.descripcion;
                document.getElementById('duracion').value = actividad.duracion;
                document.getElementById('ubicacion').value = actividad.ubicacion;
                document.getElementById('precio').value = actividad.precio;
                document.getElementById('categoria').value = actividad.categoria;
                document.getElementById('fecha').value = actividad.fecha;
                document.getElementById('hora').value = actividad.hora;
                document.getElementById('form-title').textContent = 'Editar Actividad';
                document.getElementById('actividad-form-container').style.display = 'block';
            }
        </script>
    </body>
</html>
