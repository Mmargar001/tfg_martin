
<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Actividades;  
use proyecto\Modelo\Comentarios;
use proyecto\Modelo\Itinerarios;

// Verificar si el usuario es cliente
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente')
{
    header("Location: ../Vista/login.php");
    
}

// Obtener el ID de la actividad
$actividad_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Obtener detalles de la actividad
$actividad = Actividades::obtenerActividadPorId($actividad_id);

if (!$actividad)
{
    echo "Actividad no encontrada.";
  
}

// Obtener comentarios para la actividad
$comentarios = Comentarios::obtenerComentariosPorActividad($actividad_id);

// Obtener itinerarios del usuario
$itinerarios = Itinerarios::obtenerItinerariosPorUsuario($_SESSION['usuario_id']);
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Detalles de la Actividad</title>
        <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    </head>
    <body>
        <div class="container">
            <header>
                <h1>Detalles de la Actividad</h1>
            </header>
            <main class="main-content">
                <section class="activity-detail">
                    <h2><?php echo htmlspecialchars($actividad['titulo']); ?></h2>
                    <p><strong>Descripción:</strong> <?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                    <p><strong>Duración:</strong> <?php echo htmlspecialchars($actividad['duracion']); ?></p>
                    <p><strong>Ubicación:</strong> <?php echo htmlspecialchars($actividad['ubicacion']); ?></p>
                    <p><strong>Precio:</strong> <?php echo htmlspecialchars($actividad['precio']); ?></p>
                    <p><strong>Categoría:</strong> <?php echo htmlspecialchars($actividad['categoria']); ?></p>
                    <p><strong>Fecha:</strong> <?php echo htmlspecialchars($actividad['fecha']); ?></p>
                    <p><strong>Hora:</strong> <?php echo htmlspecialchars($actividad['hora']); ?></p>

                  

                    <!-- Sección de Comentarios -->
                    <div class="comments-section">
                        <h3>Añadir valoracion</h3>
<?php foreach ($comentarios as $comentario): ?>
                            <div class="comment">
                                <p><strong><?php echo htmlspecialchars($comentario['usuario']); ?>:</strong> <?php echo htmlspecialchars($comentario['comentario']); ?></p>
                                <p>Puntuación: <?php echo htmlspecialchars($comentario['puntuacion']); ?> / 5</p>
                                <p>Fecha: <?php echo htmlspecialchars($comentario['fecha']); ?></p>

                                <!-- Botón para eliminar comentario -->
    <?php if ($comentario['usuario_id'] == $_SESSION['usuario_id']): ?>
                                    <form action="../Controlador/operacionesComentarios.php" method="post" style="display:inline;">
                                        <input type="hidden" name="comentario_id" value="<?php echo htmlspecialchars($comentario['id']); ?>">
                                        <input type="hidden" name="actividad_id" value="<?php echo htmlspecialchars($actividad['id']); ?>">
                                        <button type="submit" name="eliminar_comentario" class="delete-button">Eliminar Comentario</button>
                                    </form>
                            <?php endif; ?>
                            </div>
<?php endforeach; ?>

                        <!-- Formulario para añadir nuevo comentario -->
                        <form action="../Controlador/operacionesComentarios.php" method="post">
                            <input type="hidden" name="actividad_id" value="<?php echo htmlspecialchars($actividad['id']); ?>">
                            <textarea name="comentario" placeholder="Añade un comentario..." required></textarea>
                            <select name="puntuacion" required>
                                <option value="">Puntuación</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                            <button type="submit" name="agregar_comentario">Comentar</button>
                        </form>
                    </div>
                </section>
                </section>

                <!-- Botón para volver al perfil -->
                <section class="volver-perfil">
                    <a href="inicioCliente.php" class="back-button">Volver al Inicio</a>
                </section>
            </main>
            <footer class="footer">
                <div class="footer-container">
                    <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
                </div>
            </footer>
        </div>
    </body>
</html>
