<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Itinerarios;
use proyecto\Modelo\Notificaciones;
use proyecto\Modelo\Reservas;

// Verificar autenticación del usuario
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../Vista/login.php');
    
}

$usuario_id = $_SESSION['usuario_id'];

// Obtener el estado de las reservas del usuario
$reservas = Reservas::obtenerReservasPorUsuario($usuario_id);

// Obtener itinerarios del usuario
$itinerarios = Itinerarios::obtenerItinerariosPorUsuario($usuario_id);

// Contar las notificaciones no leídas del usuario
$notificaciones_no_leidas = intval(Notificaciones::contarNoLeidas($usuario_id));

// Determinar el mensaje a mostrar en base a los itinerarios
$mensaje = '';
if (isset($_GET['success'])) {
    $mensaje = htmlspecialchars($_GET['success']);
} elseif (isset($_GET['error'])) {
    $mensaje = htmlspecialchars($_GET['error']);
} elseif (!empty($itinerarios)) {
    $mensaje = "Tienes " . count($itinerarios) . " itinerarios. <a href='gestionReservas.php' class='nav-link'>Ver más</a>";
} else {
    $mensaje = "Actualmente no tienes itinerarios. Explora actividades <a href='listadoActividades.php' class='nav-link'>aquí</a>.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio Cliente</title>
   
     <link rel="stylesheet" type="text/css" href="../Estilos/chatbot.css">
     <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
     
    <style>
    /* Estilos del Chatbot */
.chatbot {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 300px; /* Ancho del chatbot */
    max-height: 500px; /* Altura máxima del chatbot */
    background-color: #ffffff; /* Fondo del chatbot */
    border: 1px solid #d4a373; /* Borde que coincida con el estilo general */
    border-radius: 10px; /* Bordes redondeados para coincidir con el contenedor */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Sombra */
    display: none; /* Oculto por defecto */
    flex-direction: column; /* Alinear contenido verticalmente */
    z-index: 1000; /* Asegúrate de que esté encima de otros elementos */
}

/* Muestra el chatbot cuando se activa */
.chatbot.show {
    display: flex; /* Mostrar como flex */
}

/* Encabezado del chatbot */
.chatbot-header {
    background-color: #ffcb77; /* Color de fondo del encabezado */
    color: #333; /* Color del texto */
    padding: 15px; /* Espaciado interior */
    display: flex; /* Para alinear el título y el botón de cerrar */
    justify-content: space-between; /* Espacio entre elementos */
    align-items: center; /* Centrar verticalmente */
    border-top-left-radius: 10px; /* Bordes redondeados */
    border-top-right-radius: 10px; /* Bordes redondeados */
}

/* Mensajes del chatbot */
.chatbot-messages {
    flex-grow: 1; /* Permitir que el área de mensajes crezca */
    padding: 10px; /* Espaciado interior */
    overflow-y: auto; /* Desplazamiento vertical si hay muchos mensajes */
    max-height: 400px; /* Altura máxima del área de mensajes */
}

/* Mensajes de usuario y bot */
.chatbot-messages p {
    margin: 5px 0; /* Margen entre mensajes */
    padding: 8px; /* Espaciado interior */
    border-radius: 5px; /* Bordes redondeados */
    font-size: 14px; /* Tamaño de fuente */
}

/* Mensajes del bot */
.chatbot-messages p.bot {
    background-color: #f9dec9; /* Fondo para mensajes del bot */
    color: #333; /* Color del texto */
}

/* Mensajes del usuario */
.chatbot-messages p.user {
    background-color: #f4a261; /* Fondo para mensajes del usuario */
    color: #fff; /* Color del texto */
}

/* Entrada de texto del chatbot */
#chatbot-input {
    border: 1px solid #ccc; /* Borde del campo de entrada */
    border-radius: 5px; /* Bordes redondeados */
    padding: 10px; /* Espaciado interior */
    width: calc(100% - 22px); /* Ancho completo menos padding */
    font-size: 14px; /* Tamaño de fuente */
    color: #333; /* Color del texto */
}

/* Botón de envío */
#chatbot-send {
    background-color: #2a9d8f; /* Color de fondo del botón */
    color: white; /* Color del texto */
    border: none; /* Sin borde */
    padding: 10px; /* Espaciado interior */
    border-radius: 5px; /* Bordes redondeados */
    cursor: pointer; /* Cambiar cursor al pasar por encima */
    font-size: 16px; /* Tamaño de fuente */
    transition: background-color 0.3s ease; /* Transición de fondo */
}

#chatbot-send:hover {
    background-color: #21867a; /* Color al pasar el mouse */
}

/* Botón de cerrar */
#chatbot-close {
    background: none; /* Sin fondo */
    border: none; /* Sin borde */
    color: #333; /* Color del texto */
    cursor: pointer; /* Cambiar cursor al pasar por encima */
}

/* Estilo para el botón del chatbot que aparece */
.chatbot-toggle {
    position: fixed; /* Posición fija */
    bottom: 20px; /* Espaciado desde la parte inferior */
    right: 20px; /* Espaciado desde la derecha */
    cursor: pointer; /* Cambiar cursor al pasar por encima */
}

/* Estilo para la imagen del ícono del chatbot */
.chatbot-toggle img {
    width: 50px; /* Ancho del ícono */
    height: 50px; /* Altura del ícono */
}

    </style>
</head>
<body>
    <div class="client-container">
        <header class="header">
            <h1 class="welcome-message">Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?></h1>
            <a href="login.php" class="header-link">Volver a incio sesión</a>
            <nav class="nav">
                <ul class="nav-list">
                    <li class="nav-item"><a href="crearItinerario.php" class="nav-link">Crear Itinerario</a></li>
                    <li class="nav-item"><a href="perfil.php" class="nav-link">Mi Perfil</a></li>
                    <li class="nav-item"><a href="gestionReservas.php" class="nav-link">Mis Itinerarios</a></li>
                    <li class="nav-item">
                        <a href="../Controlador/notificacionesController.php?accion=ver_notificaciones" class="nav-link">
                            Notificaciones
                            <span class="notification-badge"><?php echo $notificaciones_no_leidas; ?></span>
                        </a>
                    </li>
                    <li class="nav-item"><a href="ayuda.php" class="nav-link">Ayuda</a></li>
                    <li class="nav-item"><a href="listadoActividades.php" class="nav-link">Actividades</a></li>
                </ul>
            </nav>
        </header>

        <main class="main-content">
            <section class="section">
                <h2 class="section-title">Información</h2>
                <p><?php echo $mensaje; ?></p>
            </section>
        </main>

        <footer class="footer">
            <div class="footer-container">
                <div class="footer-column">
                    <h3>Enlaces Útiles</h3>
                    <ul class="footer-list">
                        <li><a href="nosotros.php" class="footer-link">Sobre Nosotros</a></li>
                        <li><a href="contacto.php" class="footer-link">Contacto</a></li>
                        <li><a href="privacidad.php" class="footer-link">Política de Privacidad</a></li>
                        <li><a href="terminos.php" class="footer-link">Términos y Condiciones</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Síguenos</h3>
                    <ul class="footer-list">
                        <li><a href="#" class="footer-link">Facebook</a></li>
                        <li><a href="#" class="footer-link">Twitter</a></li>
                        <li><a href="#" class="footer-link">Instagram</a></li>
                        <li><a href="#" class="footer-link">LinkedIn</a></li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>

    <!-- Botón para abrir el chatbot -->
    <div id="chatbot-toggle" class="chatbot-toggle">
        <img src="../Imagenes/chat.png" alt="Chat" />
    </div>

    <!-- Contenedor del chatbot -->
    <div id="chatbot" class="chatbot">
        <div class="chatbot-header">
            <h3>Chatbot</h3>
            <button id="chatbot-close">X</button>
        </div>
        <div id="chatbot-messages" class="chatbot-messages">
            <!-- Mensajes del chatbot aparecerán aquí -->
        </div>
        <div id="chatbot-suggestions" class="chatbot-suggestions">
            <!-- Preguntas sugeridas aparecerán aquí -->
        </div>
        <input type="text" id="chatbot-input" placeholder="¿Cómo puedo ayudarte hoy?" />
        <button id="chatbot-send">Enviar</button>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let chatbotMessages = document.getElementById('chatbot-messages');
            let chatbotInput = document.getElementById('chatbot-input');
            let chatbotSend = document.getElementById('chatbot-send');
            let chatbotClose = document.getElementById('chatbot-close');
            let chatbot = document.getElementById('chatbot');
            let chatbotToggle = document.getElementById('chatbot-toggle');
            let chatbotSuggestions = document.getElementById('chatbot-suggestions');

            // Respuestas predefinidas para el chatbot
            let responses = {
                'hola': '¡Hola! ¿En qué puedo ayudarte?',
                '¿qué es planify?': 'Planify es una herramienta para organizar tus actividades diarias. Puedes gestionar itinerarios, ver notificaciones y más.',
                '¿cómo puedo crear un itinerario?': 'Para crear un itinerario, dirígete a la sección "Crear Itinerario" en el menú principal y sigue los pasos indicados.',
                'contacto': 'Para asistencia, por favor contáctanos en soporte@example.com o visita nuestra sección de ayuda en el sitio.',
                '¿cómo puedo empezar?': 'Para empezar, te recomendamos explorar la sección "Crear Itinerario" o revisar tu perfil para ajustar tus preferencias.',
                '¿dónde puedo encontrar ayuda?': 'Puedes encontrar ayuda en la sección "Ayuda" del menú o contactarnos directamente en soporte@example.com.',
                '¿qué funcionalidades ofrece el sistema?': 'El sistema te permite crear itinerarios, gestionar tus actividades, recibir notificaciones y mucho más. Revisa el menú para explorar todas las funcionalidades.'
            };

            // Sugerencias de preguntas para el chatbot
            let suggestions = [
                '¿Cómo puedo empezar?',
                '¿Dónde puedo encontrar ayuda?',
                '¿Qué funcionalidades ofrece el sistema?'
            ];

            // Función para agregar mensajes al chatbot
            function addMessage(content, isBot = true) {
                let message = document.createElement('p');
                message.textContent = content;
                message.style.textAlign = isBot ? 'left' : 'right';
                chatbotMessages.appendChild(message);
                chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
            }

            // Mostrar sugerencias de preguntas en el chatbot
            function showSuggestions() {
                chatbotSuggestions.innerHTML = '';
                suggestions.forEach(function (suggestion) {
                    let suggestionElement = document.createElement('p');
                    suggestionElement.textContent = suggestion;
                    suggestionElement.addEventListener('click', function () {
                        chatbotInput.value = suggestion;
                        handleUserMessage();
                    });
                    chatbotSuggestions.appendChild(suggestionElement);
                });
            }

            // Manejar el mensaje del usuario en el chatbot
            function handleUserMessage() {
                let userInput = chatbotInput.value.trim().toLowerCase();
                if (userInput) {
                    addMessage(userInput, false);
                    const response = responses[userInput] || 'Lo siento, no entiendo tu pregunta. Quizás quieras saber: ' + suggestions.join(', ') + '.';
                    addMessage(response);
                    showSuggestions();
                    chatbotInput.value = '';
                }
            }

            // Configuración de eventos para el chatbot
            chatbotSend.addEventListener('click', handleUserMessage);

            chatbotInput.addEventListener('keypress', function (event) {
                if (event.key === 'Enter') {
                    handleUserMessage();
                }
            });

            chatbotClose.addEventListener('click', function () {
                chatbot.classList.remove('show');
            });

            chatbotToggle.addEventListener('click', function () {
                chatbot.classList.toggle('show');
            });
        });
    </script>
</body>
</html>
