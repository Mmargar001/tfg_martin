<?php
session_start();
require_once __DIR__ . '/../../vendor/autoload.php';
use proyecto\Modelo\Actividades;  
use proyecto\Modelo\Categorias;
use proyecto\Modelo\Comentarios;
use proyecto\Modelo\Favoritos;  
use proyecto\Modelo\Itinerarios;
// Verificar si el usuario está autenticado y tiene el rol de cliente
if (!isset($_SESSION['usuario_id']) || $_SESSION['rol'] !== 'cliente')
{
    header("Location: ../Vista/login.php");
    exit();
}

// Obtener el ID del itinerario desde la URL
$itinerario_id = isset($_GET['id']) ? intval($_GET['id']) : null;
if (!$itinerario_id)
{
    header("Location: inicioCliente.php");
    exit();
}

// Obtener detalles del itinerario y verificar que pertenece al usuario
$itinerario = Itinerarios::obtenerItinerarioPorId($itinerario_id);
if (!$itinerario || $itinerario['usuario_id'] != $_SESSION['usuario_id'])
{
    header("Location: inicioCliente.php");
    exit();
}

// Obtener actividades asociadas al itinerario
$actividadesAsociadas = Itinerarios::obtenerActividadesPorItinerario($itinerario_id);

// Obtener todas las actividades disponibles para agregar
$todasActividades = Actividades::obtenerActividades();
$actividadesDisponibles = array_filter($todasActividades, function ($actividad) use ($actividadesAsociadas) {
    foreach ($actividadesAsociadas as $asociada)
    {
        if ($asociada['id'] == $actividad['id'])
        {
            return false; // Excluir actividades ya asociadas
        }
    }
    return true;
});

// Obtener puntuación promedio para cada actividad
foreach ($actividadesAsociadas as &$actividad)
{
    $actividad['puntuacion_promedio'] = Comentarios::obtenerPuntuacionPromedio($actividad['id']);
}
foreach ($actividadesDisponibles as &$actividad)
{
    $actividad['puntuacion_promedio'] = Comentarios::obtenerPuntuacionPromedio($actividad['id']);
}

// Obtener categorías disponibles para filtrar
$categoriasDisponibles = Categorias::obtenerCategorias();

// Manejar los filtros
$fechaFiltro = isset($_POST['fecha']) ? $_POST['fecha'] : null;
$horaFiltro = isset($_POST['hora']) ? $_POST['hora'] : null;
$puntuacionFiltro = isset($_POST['puntuacion']) ? floatval($_POST['puntuacion']) : null;
$favoritosFiltro = isset($_POST['favoritos']) ? (bool) $_POST['favoritos'] : false;
$precioFiltro = isset($_POST['precio']) ? floatval($_POST['precio']) : null;
$categoriaFiltro = isset($_POST['categoria']) ? intval($_POST['categoria']) : null;

$actividadesFiltradas = array_filter($actividadesDisponibles, function ($actividad) use ($fechaFiltro, $horaFiltro, $puntuacionFiltro, $favoritosFiltro, $precioFiltro, $categoriaFiltro) {
    // Filtrar por fecha
    $dentroFecha = (!$fechaFiltro || $actividad['fecha'] === $fechaFiltro);

    // Filtrar por hora: comparando solo HH:MM (ignorando segundos)
    $horaActividad = substr($actividad['hora'], 0, 5); // Extrae solo los primeros 5 caracteres: "HH:MM"
    $horaFiltro = substr($horaFiltro, 0, 5); // Asegura que también solo compares "HH:MM"
    $dentroHora = (!$horaFiltro || $horaActividad === $horaFiltro);

    // Filtrar por puntuación
    $dentroPuntuacion = ($puntuacionFiltro === null || $actividad['puntuacion_promedio'] >= $puntuacionFiltro);

    // Filtrar por favoritos
    $esFavorita = (!$favoritosFiltro || Favoritos::esFavorito($_SESSION['usuario_id'], $actividad['id']));

    // Filtrar por precio
    $dentroPrecio = (!$precioFiltro || $actividad['precio'] <= $precioFiltro);

    // Filtrar por categoría
    $dentroCategoria = (!$categoriaFiltro || $actividad['categoria'] == $categoriaFiltro);

    return $dentroFecha && $dentroHora && $dentroPuntuacion && $esFavorita && $dentroPrecio && $dentroCategoria;
});

// Obtener el mensaje de error o éxito si existe
$error = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : null;
$success = isset($_GET['success']) ? htmlspecialchars($_GET['success']) : null;
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gestión de Itinerario</title>
        <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
        <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
    </head>
    <body>
        <div class="gestion-itinerario-container">
            <header class="header">
                <h1>Gestión de Itinerario: <?php echo htmlspecialchars($itinerario['nombre']); ?></h1>
                    <a href="inicioCliente.php" class="a">Volver al área del cliente</a>
            </header>
            <main class="main-content">
                <!-- Mensajes de error o éxito -->
                <?php if ($error): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>

                <!-- Sección de detalles del itinerario -->
                <section class="itinerario-detalle">
                    <h2>Actividades en este Itinerario</h2>
                    <!-- Muestra el presupuesto total del itinerario -->
                    <p><strong>Presupuesto total del Itinerario:</strong> <?php echo htmlspecialchars($itinerario['presupuesto']); ?> €</p>

                    <!-- Verifica si hay actividades asociadas al itinerario -->
                    <?php if (empty($actividadesAsociadas)): ?>
                        <p>No hay actividades en este itinerario.</p>
                    <?php else: ?>
                        <ul>
                            <!-- Lista todas las actividades asociadas al itinerario -->
                            <?php foreach ($actividadesAsociadas as $actividad): ?>
                                <li>
                                    <!-- Muestra los detalles de cada actividad -->
                                    <h3><?php echo htmlspecialchars($actividad['titulo']); ?></h3>
                                    <p><?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                                    <p>Duración: <?php echo htmlspecialchars($actividad['duracion']); ?> horas</p>
                                    <p>Ubicación: <?php echo htmlspecialchars($actividad['ubicacion']); ?></p>
                                    <p>Fecha: <?php echo htmlspecialchars($actividad['fecha']); ?></p>
                                    <p>Hora: <?php echo htmlspecialchars($actividad['hora']); ?></p>
                                    <p>Precio: <?php echo htmlspecialchars($actividad['precio']); ?> €</p>

                                    <!-- Formulario para eliminar la actividad del itinerario -->
                                    <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                                        <input type="hidden" name="itinerario_id" value="<?php echo $itinerario_id; ?>">
                                        <input type="hidden" name="actividad_id" value="<?php echo $actividad['id']; ?>">
                                        <button type="submit" name="eliminar_actividad" class="delete-button">Eliminar Actividad</button>
                                    </form>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </section>

                <!-- Sección para agregar nuevas actividades -->
                <section class="agregar-actividades">
                    <h2>Agregar Nuevas Actividades</h2>
                    <!-- Formulario de filtro para buscar actividades -->
                    <form id="filtro-form" method="post" action="">
                        <div class="form-group">
                            <label for="categoria">Filtrar por Categoría:</label>
                            <select id="categoria" name="categoria">
                                <option value="">Cualquier Categoría</option>
                                <!-- Lista las categorías disponibles y marca la categoría seleccionada -->
                                <?php foreach ($categoriasDisponibles as $categoria): ?>
                                    <option value="<?php echo htmlspecialchars($categoria['id']); ?>" <?php echo $categoriaFiltro == $categoria['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($categoria['nombre']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="fecha">Filtrar por Fecha:</label>
                            <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($fechaFiltro); ?>">
                        </div>

                        <div class="form-group">
                            <label for="hora">Filtrar por Hora:</label>
                            <input type="time" id="hora" name="hora" value="<?php echo htmlspecialchars($horaFiltro); ?>">
                        </div>

                        <div class="form-group">
                            <label for="puntuacion">Filtrar por Puntuación:</label>
                            <select id="puntuacion" name="puntuacion">
                                <option value="">Cualquier Puntuación</option>
                                <!-- Lista las puntuaciones disponibles y marca la seleccionada -->
                                <option value="1" <?php echo $puntuacionFiltro == 1 ? 'selected' : ''; ?>>1</option>
                                <option value="2" <?php echo $puntuacionFiltro == 2 ? 'selected' : ''; ?>>2</option>
                                <option value="3" <?php echo $puntuacionFiltro == 3 ? 'selected' : ''; ?>>3</option>
                                <option value="4" <?php echo $puntuacionFiltro == 4 ? 'selected' : ''; ?>>4</option>
                                <option value="5" <?php echo $puntuacionFiltro == 5 ? 'selected' : ''; ?>>5</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="precio">Filtrar por Precio (Máximo):</label>
                            <input type="number" id="precio" name="precio" step="0.01" value="<?php echo htmlspecialchars($precioFiltro); ?>">
                        </div>

                        <div class="form-group">
                            <label for="favoritos">Solo Favoritos:</label>
                            <input type="checkbox" id="favoritos" name="favoritos" <?php echo $favoritosFiltro ? 'checked' : ''; ?>>
                        </div>

                        <!-- Botón para aplicar el filtro -->
                        <button type="submit" class="submit-button">Filtrar Actividades</button>

                        <!-- Botón para limpiar el formulario de filtro -->
                        <button type="button" class="clear-form-button" onclick="limpiarFormulario()">Limpiar Formulario</button>
                    </form>

                    <h3>Actividades Disponibles</h3>
                    <ul id="actividades-lista">
                        <!-- Lista de actividades filtradas que serán cargadas mediante AJAX -->
                        <?php foreach ($actividadesFiltradas as $actividad): ?>
                            <li>
                                <!-- Muestra los detalles de cada actividad filtrada -->
                                <h3><?php echo htmlspecialchars($actividad['titulo']); ?></h3>
                                <p><?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                                <p>Duración: <?php echo htmlspecialchars($actividad['duracion']); ?> horas</p>
                                <p>Precio: <?php echo htmlspecialchars($actividad['precio']); ?> €</p>
                                <p>Hora: <?php echo htmlspecialchars($actividad['hora']); ?></p>

                                <!-- Formulario para agregar la actividad al itinerario -->
                                <form method="post" action="../Controlador/operacionesItinerario.php" style="display:inline;">
                                    <input type="hidden" name="itinerario_id" value="<?php echo $itinerario_id; ?>">
                                    <input type="hidden" name="actividad_id" value="<?php echo $actividad['id']; ?>">
                                    <button type="submit" name="agregar_actividad" class="add-button">Agregar al Itinerario</button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </section>
            </main>

        </div>

        <script>


            // Función para limpiar todo el formulario (filtros y campos de actividades)
            function limpiarFormulario() {
                // Limpiar los valores de todos los filtros
                document.getElementById('filtro-form').reset();

                // Asegurarse de que los campos tipo select se restablezcan al valor predeterminado
                const selectFields = document.querySelectorAll('select');
                selectFields.forEach(function (select) {
                    select.selectedIndex = 0; // Restablecer la selección al primer valor (valor por defecto)
                });

                // Limpiar los campos de fecha
                const dateFields = document.querySelectorAll('input[type="date"]');
                dateFields.forEach(function (input) {
                    input.value = ''; // Restablecer el valor del campo de fecha
                });

                // Limpiar los campos de hora
                const timeFields = document.querySelectorAll('input[type="time"]');
                timeFields.forEach(function (input) {
                    input.value = ''; // Restablecer el valor del campo de hora
                });

                // Limpiar los campos de checkbox
                const checkboxFields = document.querySelectorAll('input[type="checkbox"]');
                checkboxFields.forEach(function (checkbox) {
                    checkbox.checked = false; // Desmarcar todos los checkboxes
                });

                // Limpiar los campos numéricos (si los hubiera)
                const numberFields = document.querySelectorAll('input[type="number"]');
                numberFields.forEach(function (input) {
                    input.value = ''; // Limpiar el valor de los campos numéricos
                });

                // Limpiar la lista de actividades si es necesario
                $('#actividades-lista').empty();  // Limpiar la lista de actividades disponibles

                // Opcional: Recargar todas las actividades nuevamente
                $.post("", {}, function (data) {
                    // Actualizar la lista de actividades con todas las disponibles
                    $('#actividades-lista').html($(data).find('#actividades-lista').html());
                });
            }


        </script>
    </body>
</html>
