<?php 
session_start();
use proyecto\Modelo\Usuarios;
require_once __DIR__ . '/../../vendor/autoload.php';
$usuarioLogueado = false;
$nombre = '';
$email = '';

if (isset($_SESSION['usuario_id'])) {
    $usuarioLogueado = true;
    $usuario = Usuarios::obtenerUsuarioPorID($_SESSION['usuario_id']);
    if ($usuario) {
        $nombre = $usuario['nombre'];
        $email = $usuario['email'];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
    <style>
        .success-message {
            display: none;
            padding: 15px;
            margin: 20px 0;
            background-color: #dff0d8;
            color: #3c763d;
            border: 1px solid #d0e9c6;
            border-radius: 5px;
            text-align: center;
            font-size: 1.2em;
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Contacto</h1>
            <p class="welcome-message">Completa el formulario a continuación y nos pondremos en contacto contigo.</p>
            <!-- Enlace para volver al inicio -->
            <a href="<?php echo isset($_SESSION['usuario']) ? 'inicioCliente.php' : 'login.php'; ?>" class="nav-link">Volver a Inicio</a>
        </header>

        <!-- Mensaje de éxito (inicialmente oculto) -->
        <div id="successMessage" class="success-message">
            <p>Tu mensaje ha sido enviado correctamente. Nos pondremos en contacto contigo lo antes posible.</p>
        </div>

        <form id="contactForm" method="post" class="form-container">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>" <?php echo $usuarioLogueado ? 'readonly' : 'required'; ?> 
                    pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Por favor, ingresa un nombre válido. Solo letras y espacios son permitidos.">
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" <?php echo ($usuarioLogueado && !empty($email)) ? 'readonly' : 'required'; ?> 
                    pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" title="Por favor, ingresa un correo electrónico válido.">
            </div>

            <div class="form-group">
                <label for="mensaje">Mensaje:</label>
                <textarea id="mensaje" name="mensaje" required minlength="10" title="El mensaje debe tener al menos 10 caracteres."></textarea>
            </div>

            <input type="submit" value="Enviar" class="submit-button">
        </form>
    </div>

    <script>
        // Obtiene el formulario y el mensaje de éxito
        let contactForm = document.getElementById("contactForm");
        let successMessage = document.getElementById("successMessage");

        // Función de validación
        contactForm.addEventListener("submit", function(event) {
            event.preventDefault(); // Evita el envío del formulario

            let nombreInput = document.getElementById("nombre");
            let emailInput = document.getElementById("email");
            let mensajeInput = document.getElementById("mensaje");

            let nombrePattern = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/;
            let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

            // Validación para el nombre (solo letras y espacios)
            if (!nombrePattern.test(nombreInput.value)) {
                alert("Por favor, ingresa un nombre válido.");
                return false;
            }

            // Validación para el correo electrónico
            if (!emailPattern.test(emailInput.value)) {
                alert("Por favor, ingresa un correo electrónico válido.");
                return false;
            }

            // Validación para el mensaje (mínimo 10 caracteres)
            if (mensajeInput.value.length < 10) {
                alert("El mensaje debe tener al menos 10 caracteres.");
                return false;
            }

            // Si todo está bien, muestra el mensaje de éxito
            successMessage.style.display = "block";
        });
    </script>
</body>
</html>
