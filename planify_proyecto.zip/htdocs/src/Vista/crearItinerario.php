<!DOCTYPE html>
<html lang="es">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <title>Crear Itinerario</title>
    
    
    <link rel="stylesheet" type="text/css" href="../Estilos/estilosComunes.css">
</head>
<body>
    <div class="container">
        <!-- Cabecera con el título de la página y un enlace para volver al área cliente -->
        <header class="header">
            <h1>Crear Itinerario</h1>
            <a href="inicioCliente.php">Volver al área cliente</a>
        </header>

        <main class="main-content">
            <!-- Formulario para la creación de un itinerario -->
            <div class="itinerary-area">
                <h2>Nuevo Itinerario</h2>
                <form action="../Controlador/operacionesItinerario.php" method="post" id="itinerary-form">
                    <!-- Campo para el nombre del itinerario -->
                    <div class="form-group">
                        <label for="nombre">Nombre del Itinerario:</label>
                        <input type="text" id="nombre" name="nombre" required>
                    </div>

                    <!-- Campo para la descripción del itinerario -->
                    <div class="form-group">
                        <label for="descripcion">Descripción del Itinerario:</label>
                        <textarea id="descripcion" name="descripcion" required></textarea>
                    </div>

                    <!-- Campo para el presupuesto del itinerario -->
                    <div class="form-group">
                        <label for="presupuesto">Presupuesto del Itinerario (€):</label>
                        <input type="number" id="presupuesto" name="presupuesto" min="0" step="0.01" required>
                    </div>

                    <!-- Botón para enviar el formulario y guardar el itinerario -->
                    <button type="submit" name="crear_itinerario" class="button dange">Guardar Itinerario</button>
                </form>
            </div>

            <!-- Mostrar mensajes de error o éxito según el estado de la operación -->
            <?php if (isset($_GET['error'])): ?>
                <p class="error-message"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php elseif (isset($_GET['success'])): ?>
                <p class="success-message"><?php echo htmlspecialchars($_GET['success']); ?></p>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
