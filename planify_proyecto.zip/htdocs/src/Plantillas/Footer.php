  </main>
    <footer>
        <p>&copy; 2024 Mi Proyecto</p>
    </footer>
    <script src="<?php echo BASE_URL; ?>/js/scripts.js"></script>
</body>
</html>