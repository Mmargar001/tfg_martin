<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Proyecto</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/Estilos/estilos.css">
</head>
<body>
    <header>
        <h1>Bienvenido a Mi Proyecto</h1>
        <nav>
            <ul>
                <li><a href="<?php echo BASE_URL; ?>/index.php">Inicio</a></li>
                <li><a href="<?php echo BASE_URL; ?>/Vista/registro.php">Registro</a></li>
                <!-- Añade más enlaces según sea necesario -->
            </ul>
        </nav>
    </header>
    <main>
    </main>
</body>
</html>