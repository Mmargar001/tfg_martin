<?php  

namespace proyecto\Modelo;
use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;
class Usuarios {      
    // Crea un nuevo usuario     
public static function crearUsuario($nombre, $clave, $tipo_usuario) {         
    // Validación de los parámetros
    if (empty($nombre) || empty($clave) || empty($tipo_usuario)) {
        return false; // Si algún parámetro está vacío, devolver false
    }

    // Establece la conexión con la base de datos
    $conexion = Conexion::conectar();         

    // Prepara la consulta SQL para insertar un nuevo usuario
             
    $stmt = $conexion->prepare("INSERT INTO usuarios (nombre, clave, tipo) VALUES (:nombre, :clave, :tipo_usuario)");         
    
    // Vincula los parámetros con los valores correspondientes
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':clave', $clave);
    $stmt->bindParam(':tipo_usuario', $tipo_usuario);

    // Ejecuta la consulta e inserta el usuario en la base de datos
    return $stmt->execute();     
}

    // Elimina un usuario      
public static function eliminarUsuario($id) {
    // Validar que el ID no esté vacío
    if (empty($id)) {
        return false; // Si el ID está vacío, devolver false
    }

    try {
        $conexion = Conexion::conectar();         
        $stmt = $conexion->prepare("DELETE FROM usuarios WHERE id = :id");         
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        // Verificar si se eliminó alguna fila
        return $stmt->rowCount() > 0;
    } catch (Exception $e) {
        error_log($e->getMessage());
        return false;  // Si ocurre un error, retornar false
    }
}



    // Obtiene todos los usuarios     
    public static function obtenerUsuarios() {         
        $conexion = Conexion::conectar();         
        $stmt = $conexion->prepare("SELECT * FROM usuarios");         
        $stmt->execute();         
        return $stmt->fetchAll(PDO::FETCH_ASSOC);     
    }      

    // Obtiene un usuario por su nombre     
 public static function obtenerUsuarioPorNombre($nombre) {         
    $conexion = Conexion::conectar();         
             
    $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE nombre = :nombre LIMIT 1");         
    $stmt->bindParam(':nombre', $nombre);
    $stmt->execute();         

    // Devuelve null si no se encuentra ningún usuario
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);     
    return $usuario ?: null;  // Retorna null si no se encontró un usuario
}


    // Obtiene un usuario por ID     
public static function obtenerUsuarioPorID($id) {         
    $conexion = Conexion::conectar();         
    $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE id = :id LIMIT 1");         
    $stmt->bindParam(':id', $id);
    $stmt->execute();         
    
    // Devolver null si no se encuentra ningún usuario
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;     
}


    // Actualiza un usuario
public static function actualizarUsuario($id, $nuevo_nombre, $nuevo_email, $nuevo_telefono) {
    // Validar parámetros
    if (empty($nuevo_nombre) || empty($nuevo_email) || empty($nuevo_telefono) || empty($id)) {
        return false; // Si algún parámetro está vacío, devolver false
    }
    
    $conexion = Conexion::conectar();
    
    $stmt = $conexion->prepare("UPDATE usuarios SET nombre = :nuevo_nombre, email = :nuevo_email, telefono = :nuevo_telefono WHERE id = :id");
    $stmt->bindParam(':nuevo_nombre', $nuevo_nombre);
    $stmt->bindParam(':nuevo_email', $nuevo_email);
    $stmt->bindParam(':nuevo_telefono', $nuevo_telefono);
    $stmt->bindParam(':id', $id);
    
    // Ejecuta la consulta
    $stmt->execute();

    // Verifica si realmente se actualizó algún registro
    return $stmt->rowCount() > 0;
}

//Actualizar contraseña
public static function actualizarContrasena($id, $nuevaContrasena) {
    $conexion = Conexion::conectar();
    $stmt = $conexion->prepare("UPDATE usuarios SET clave = :clave WHERE id = :id");
    $stmt->bindParam(':clave', $nuevaContrasena, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    return $stmt->execute();
}





}
?>
