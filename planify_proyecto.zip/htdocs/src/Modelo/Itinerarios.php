<?php

namespace proyecto\Modelo;
use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;

class Itinerarios {

    // Crea un nuevo itinerario o actualiza uno existente
    public static function crearOActualizarItinerario($usuarioId, $nombre, $descripcion, $presupuesto)
    {
        $conexion = Conexion::conectar();

        try {
            // Verificar si ya existe un itinerario con el mismo nombre y usuario
            $stmt = $conexion->prepare('SELECT id FROM itinerarios WHERE usuario_id = :usuario_id AND nombre = :nombre');
            $stmt->bindParam(':usuario_id', $usuarioId);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($resultado) {
                // Si existe, actualizar el presupuesto y la descripción
                $itinerario_id = $resultado['id'];
                $stmt = $conexion->prepare('UPDATE itinerarios SET descripcion = :descripcion, presupuesto = :presupuesto WHERE id = :id');
                $stmt->bindParam(':descripcion', $descripcion);
                $stmt->bindParam(':presupuesto', $presupuesto);
                $stmt->bindParam(':id', $itinerario_id);
                $stmt->execute();

                // Verificar si la actualización afectó filas
                return $stmt->rowCount() > 0;
            } else {
                // Si no existe, crear uno nuevo
                $stmt = $conexion->prepare('INSERT INTO itinerarios (usuario_id, nombre, descripcion, fecha_creacion, presupuesto) VALUES (:usuario_id, :nombre, :descripcion, NOW(), :presupuesto)');
                $stmt->bindParam(':usuario_id', $usuarioId);
                $stmt->bindParam(':nombre', $nombre);
                $stmt->bindParam(':descripcion', $descripcion);
                $stmt->bindParam(':presupuesto', $presupuesto);
                $stmt->execute();

                // Verificar si la inserción afectó filas
                return $stmt->rowCount() > 0;
            }
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    // Elimina un itinerario por ID
    public static function eliminarItinerario($id)
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("DELETE FROM itinerarios WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        // Verificar si la eliminación afectó filas
        return $stmt->rowCount() > 0;
    }

    // Obtiene todos los itinerarios
    public static function obtenerTodosItinerarios()
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("SELECT * FROM itinerarios");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Obtiene itinerarios de un usuario
    public static function obtenerItinerariosPorUsuario($usuario_id)
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("SELECT * FROM itinerarios WHERE usuario_id = :usuario_id");
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtiene actividades por itinerario
    public static function obtenerActividadesPorItinerario($itinerario_id)
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("
            SELECT a.*
            FROM actividades a
            INNER JOIN itinerario_actividades ia ON a.id = ia.actividad_id
            WHERE ia.itinerario_id = :itinerario_id
        ");
        $stmt->bindParam(':itinerario_id', $itinerario_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Agrega una actividad a un itinerario
    public static function agregarActividad($itinerario_id, $actividad_id)
    {
        $conexion = Conexion::conectar();

        try {
            $stmt = $conexion->prepare("INSERT INTO itinerario_actividades (itinerario_id, actividad_id) VALUES (:itinerario_id, :actividad_id)");
            $stmt->bindParam(':itinerario_id', $itinerario_id);
            $stmt->bindParam(':actividad_id', $actividad_id);
            $stmt->execute();

            // Verificar si la inserción afectó filas
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    // Elimina una actividad de un itinerario
    public static function eliminarActividad($itinerario_id, $actividad_id)
    {
        $conexion = Conexion::conectar();

        try {
            $stmt = $conexion->prepare("DELETE FROM itinerario_actividades WHERE itinerario_id = :itinerario_id AND actividad_id = :actividad_id");
            $stmt->bindParam(':itinerario_id', $itinerario_id);
            $stmt->bindParam(':actividad_id', $actividad_id);
            $stmt->execute();

            // Verificar si la eliminación afectó filas
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    // Obtiene un itinerario por ID
    public static function obtenerItinerarioPorId($id)
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("SELECT * FROM itinerarios WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function obtenerNombreItinerarioPorId($itinerario_id)
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("SELECT nombre FROM itinerarios WHERE id = :itinerario_id");
        $stmt->bindParam(':itinerario_id', $itinerario_id);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? $resultado['nombre'] : null;
    }

    public static function contarActividades($itinerario_id)
    {
        $conexion = Conexion::conectar();
        $sql = "SELECT COUNT(*) AS total FROM itinerario_actividades WHERE itinerario_id = :itinerario_id";
        $stmt = $conexion->prepare($sql);
        $stmt->bindParam(':itinerario_id', $itinerario_id);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? (int) $resultado['total'] : 0;
    }

    public static function obtenerItinerariosFiltrados($usuario_id = null, $fecha_creacion = null)
    {
        $conexion = Conexion::conectar();
        $sql = "SELECT * FROM itinerarios WHERE 1=1";

        if ($usuario_id !== null && $usuario_id !== '') {
            $sql .= " AND usuario_id = :usuario_id";
        }

        if ($fecha_creacion !== null && $fecha_creacion !== '') {
            $sql .= " AND fecha_creacion = :fecha_creacion";
        }

        $stmt = $conexion->prepare($sql);

        if ($usuario_id !== null && $usuario_id !== '') {
            $stmt->bindParam(':usuario_id', $usuario_id);
        }

        if ($fecha_creacion !== null && $fecha_creacion !== '') {
            $stmt->bindParam(':fecha_creacion', $fecha_creacion);
        }

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    //Actualiza el nombre de un itineraio
public static function actualizarNombreItinerario($itinerario_id, $nuevo_nombre) {
   $conexion = Conexion::conectar();
    $stmt =  $conexion->prepare("UPDATE itinerarios SET nombre = :nombre WHERE id = :itinerario_id");

    // Vincular parámetros
    $stmt->bindParam(':nombre', $nuevo_nombre);
    $stmt->bindParam(':itinerario_id', $itinerario_id);

    // Ejecutar la consulta y devolver el resultado
    return $stmt->execute();
}

}

?>
