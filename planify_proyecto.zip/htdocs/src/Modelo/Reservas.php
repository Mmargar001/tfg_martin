<?php

namespace proyecto\Modelo;

use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;

class Reservas {

    // Crea una nueva reserva
    public static function crearReserva($itinerario_id, $usuario_id, $monto)
    {
        $conexion = Conexion::conectar();

        if (is_null($itinerario_id) || is_null($usuario_id) || is_null($monto))
        {
            return false; // Devuelve false si algún dato requerido es nulo
        }
        try {
            $stmt = $conexion->prepare('INSERT INTO reservas (itinerario_id, usuario_id, monto) VALUES (:itinerario_id, :usuario_id, :monto)');
            $stmt->bindParam(':itinerario_id', $itinerario_id);
            $stmt->bindParam(':usuario_id', $usuario_id);
            $stmt->bindParam(':monto', $monto);
            $stmt->execute();

            return $conexion->lastInsertId(); // Devolver el ID de la nueva reserva
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    // Obtiene reservas de un usuario
    public static function obtenerReservasPorUsuario($usuario_id)
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("SELECT * FROM reservas WHERE usuario_id = :usuario_id");
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtiene una reserva por ID
public static function obtenerReservaPorId($reserva_id)
{
    $conexion = Conexion::conectar();
    $stmt = $conexion->prepare("SELECT * FROM reservas WHERE id = :reserva_id");
    $stmt->bindParam(':reserva_id', $reserva_id);
    $stmt->execute();
    
    // Cambiar de false a null cuando no se encuentra ninguna reserva
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    return $resultado ? $resultado : null;
}


    // Actualiza el estado de una reserva
public static function actualizarEstado($reserva_id, $nuevoEstado)
{
    $conexion = Conexion::conectar();

    // Definir los estados válidos
    $estadosValidos = ['pendiente', 'confirmada', 'cancelada', 'pagada'];

    // Comprobar si el estado es válido
    if (!in_array($nuevoEstado, $estadosValidos)) {
        return false;
    }

    // Verificar si la reserva existe
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM reservas WHERE id = :reserva_id");
    $stmt->bindParam(':reserva_id', $reserva_id);
    $stmt->execute();
    $reservaExiste = $stmt->fetchColumn() > 0;

    if (!$reservaExiste) {
        return false; // Si la reserva no existe, retornar false
    }

    try {
        // Si la reserva existe, actualizamos el estado
        $stmt = $conexion->prepare("UPDATE reservas SET estado = :estado WHERE id = :reserva_id");
        $stmt->bindParam(':estado', $nuevoEstado);
        $stmt->bindParam(':reserva_id', $reserva_id);
        $stmt->execute();

        return true; // La actualización fue exitosa
    } catch (Exception $e) {
        error_log($e->getMessage());
        return false; // Si ocurre un error en la ejecución, retornamos false
    }
}



    // Cancela una reserva
    public static function cancelarReserva($reserva_id)
    {
        return self::actualizarEstado($reserva_id, 'cancelada');
    }

    // Confirma una reserva
    public static function confirmarReserva($reserva_id)
    {
        return self::actualizarEstado($reserva_id, 'confirmada');
    }

    // Marca una reserva como pagada
    public static function pagarReserva($reserva_id)
    {
        return self::actualizarEstado($reserva_id, 'pagada');
    }

    // Elimina una reserva
  public static function eliminarReserva($reserva_id)
{
    $conexion = Conexion::conectar();

    // Verificar si la reserva existe
    $stmt = $conexion->prepare('SELECT COUNT(*) FROM reservas WHERE id = :reserva_id');
    $stmt->bindParam(':reserva_id', $reserva_id);
    $stmt->execute();
    $reservaExiste = $stmt->fetchColumn() > 0;

    if (!$reservaExiste) {
        return false;  // Si la reserva no existe, devolver false
    }

    try {
        $stmt = $conexion->prepare('DELETE FROM reservas WHERE id = :reserva_id');
        $stmt->bindParam(':reserva_id', $reserva_id);
        $stmt->execute();
        return true;  // Si la reserva fue eliminada correctamente
    } catch (Exception $e) {
        error_log($e->getMessage());
        return false;  // En caso de error, devolver false
    }
}


    // Obtiene el costo total de las actividades de una reserva
    public static function obtenerCosteTotalActividades($itinerario_id)
    {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("
            SELECT SUM(a.precio) as total
            FROM actividades a
            INNER JOIN itinerario_actividades ia ON a.id = ia.actividad_id
            WHERE ia.itinerario_id = :itinerario_id
        ");
        $stmt->bindParam(':itinerario_id', $itinerario_id);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? floatval($resultado['total']) : 0;
    }

    // Actualiza el presupuesto de una reserva
public static function actualizarPresupuesto($itinerario_id, $monto)
{
    $conexion = Conexion::conectar();

    // Verificar si el itinerario existe
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM itinerarios WHERE id = :itinerario_id");
    $stmt->bindParam(':itinerario_id', $itinerario_id);
    $stmt->execute();
    $itinerarioExiste = $stmt->fetchColumn() > 0;

    if (!$itinerarioExiste) {
        return false; // Si el itinerario no existe, retornar false
    }

    try {
        // Si el itinerario existe, actualizar el presupuesto
        $stmt = $conexion->prepare("UPDATE itinerarios SET presupuesto = presupuesto + :monto WHERE id = :itinerario_id");
        $stmt->bindParam(':monto', $monto);
        $stmt->bindParam(':itinerario_id', $itinerario_id);
        return $stmt->execute(); // Devolver el resultado de la ejecución del update
    } catch (Exception $e) {
        error_log($e->getMessage());
        return false; // Si ocurre un error, retornar false
    }
}


    // Obtiene el presupuesto de una reserva
public static function obtenerPresupuesto($itinerario_id)
{
    $conexion = Conexion::conectar();
    $stmt = $conexion->prepare("SELECT presupuesto FROM itinerarios WHERE id = :itinerario_id");
    $stmt->bindParam(':itinerario_id', $itinerario_id);
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    // Convertir el resultado a float explícitamente
    return isset($resultado['presupuesto']) ? floatval($resultado['presupuesto']) : 0;
}

}

?>
