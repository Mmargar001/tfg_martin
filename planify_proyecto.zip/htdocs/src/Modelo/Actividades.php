<?php

namespace proyecto\Modelo;
use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;

class Actividades {

    // Comprobar si una actividad existe, ya sea por id o por título, fecha y hora
    private static function comprobarActividadExistente($id = null, $titulo = null, $fecha = null, $hora = null) {
        $conexion = Conexion::conectar();
        
        // Si se pasa el ID, buscamos por ID
        if ($id) {
            $query = "SELECT COUNT(*) FROM actividades WHERE id = :id";
            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':id', $id);
        } 
        // Si no se pasa ID, buscamos por título, fecha y hora
        elseif ($titulo && $fecha && $hora) {
            $query = "SELECT COUNT(*) FROM actividades WHERE titulo = :titulo AND fecha = :fecha AND hora = :hora";
            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':titulo', $titulo);
            $stmt->bindParam(':fecha', $fecha);
            $stmt->bindParam(':hora', $hora);
        } else {
            return false; // Si no se pasa ningún parámetro, no se puede verificar
        }

        $stmt->execute();
        return $stmt->fetchColumn() > 0;  // Devuelve true si existe la actividad, false si no
    }

    // Crear una nueva actividad
    public static function crearActividad($titulo, $descripcion, $duracion, $ubicacion, $precio, $categoria, $fecha, $hora) {
        // Validaciones
        if (empty($titulo) || empty($descripcion) || $duracion <= 0 || $precio < 0 || empty($ubicacion) || empty($categoria) || empty($fecha) || empty($hora)) {
            return false;
        }

        // Comprobar si la actividad ya existe
        if (!self::comprobarActividadExistente(null, $titulo, $fecha, $hora)) {
     

        // Si no existe, proceder con la creación
        $conexion = Conexion::conectar();
        $query = "INSERT INTO actividades (titulo, descripcion, duracion, ubicacion, precio, categoria, fecha, hora) VALUES (:titulo, :descripcion, :duracion, :ubicacion, :precio, :categoria, :fecha, :hora)";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':titulo', $titulo);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':duracion', $duracion);
        $stmt->bindParam(':ubicacion', $ubicacion);
        $stmt->bindParam(':precio', $precio);
        $stmt->bindParam(':categoria', $categoria);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':hora', $hora);
        return $stmt->execute();
        }
    }

    // Editar una actividad existente
    public static function editarActividad($id, $titulo, $descripcion, $duracion, $ubicacion, $precio, $categoria, $fecha, $hora) {
        // Validaciones de entrada
        if (empty($titulo) || empty($descripcion) || $duracion <= 0 || $precio < 0 || empty($ubicacion) || empty($categoria) || empty($fecha) || empty($hora)) {
            return false;  // Devuelve false si los parámetros no son válidos
        }

        // Comprobar si la actividad con el ID existe
        if (!self::comprobarActividadExistente($id)) {
            return false;  // La actividad no existe
        }

        // Procedemos a actualizar la actividad
        $conexion = Conexion::conectar();
        $query = "UPDATE actividades SET titulo = :titulo, descripcion = :descripcion, duracion = :duracion, ubicacion = :ubicacion, precio = :precio, categoria = :categoria, fecha = :fecha, hora = :hora WHERE id = :id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':titulo', $titulo);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':duracion', $duracion);
        $stmt->bindParam(':ubicacion', $ubicacion);
        $stmt->bindParam(':precio', $precio);
        $stmt->bindParam(':categoria', $categoria);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':hora', $hora);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();  // Devuelve el resultado de la ejecución del UPDATE
    }

    // Eliminar una actividad
    public static function eliminarActividad($id) {
        // Comprobar si la actividad con el ID existe
        if (!self::comprobarActividadExistente($id)) {
            return false;  // La actividad no existe
        }

        // Procedemos a eliminar la actividad
        $conexion = Conexion::conectar();
        $query = "DELETE FROM actividades WHERE id = :id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Obtener todas las actividades
    public static function obtenerActividades() {
        $conexion = Conexion::conectar();
        $query = "SELECT * FROM actividades";
        $stmt = $conexion->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener una actividad por ID
    public static function obtenerActividadPorId($id) {
        $conexion = Conexion::conectar();
        $query = "SELECT * FROM actividades WHERE id = :id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $actividad = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($actividad) {
            return $actividad;
        }
        return false;
    }

    // Obtener actividades filtradas por fecha
    public static function obtenerActividadesPorFecha($fecha) {
        $conexion = Conexion::conectar();
        $query = "SELECT * FROM actividades WHERE fecha = :fecha";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener actividades filtradas por hora
    public static function obtenerActividadesPorHora($hora) {
        $conexion = Conexion::conectar();
        $query = "SELECT * FROM actividades WHERE hora = :hora";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':hora', $hora);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener actividades filtradas por fecha y hora
    public static function obtenerActividadesFiltradas($fecha, $hora = null) {
        $conexion = Conexion::conectar();
        if ($hora) {
            $query = "SELECT * FROM actividades WHERE fecha = :fecha AND hora = :hora";
            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':fecha', $fecha);
            $stmt->bindParam(':hora', $hora);
        } else {
            $query = "SELECT * FROM actividades WHERE fecha = :fecha";
            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':fecha', $fecha);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Verificar si existe solapamiento en una fecha y hora dadas
    public static function verificarSolapamiento($fecha, $hora, $duracion) {
        $conexion = Conexion::conectar();
        
        // Calculamos la hora final de la actividad
        $horaFinal = date('H:i', strtotime($hora . ' + ' . $duracion . ' hours'));

        $query = "SELECT * FROM actividades WHERE fecha = :fecha AND (hora <= :hora AND hora >= :horaFinal)";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':hora', $hora);
        $stmt->bindParam(':horaFinal', $horaFinal);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener actividades favoritas de un usuario
    public static function obtenerActividadesFavoritas($usuario_id) {
        $conexion = Conexion::conectar();
        $query = "SELECT a.* FROM actividades a JOIN favoritos f ON a.id = f.actividad_id WHERE f.usuario_id = :usuario_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
