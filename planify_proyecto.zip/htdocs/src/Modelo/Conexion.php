<?php

namespace proyecto\Modelo;
use PDO;

// Clase Conexion para gestionar la conexión a la base de datos
class Conexion {
    private const LOCALHOST ='sql301.byethost18.com';
    private const USER ='b18_37965975';
    private const PASSWORD ='planify2219';
    private const DATABASE ='b18_37965975_planify';
    
    // Propiedad estática para mantener la instancia de la conexión
    protected static $conexion = null;

    // Método para conectar a la base de datos
    public static function conectar() {
        // Asignación de variables de configuración
        $host = Conexion::LOCALHOST;
        $user = Conexion::USER;
        $password = Conexion::PASSWORD;
        $database = Conexion::DATABASE;
        
        // Verificación si la conexión no ha sido creada anteriormente
        if(is_null(Conexion::$conexion)){
            // Creación de la conexión utilizando PDO
            Conexion::$conexion = new PDO("mysql:host=$host;dbname=$database;charset=utf8mb4", $user, $password);
            // Configuración de los atributos de la conexión
            Conexion::$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // Deshabilitar las verificaciones de claves foráneas temporalmente
            Conexion::$conexion->exec("SET FOREIGN_KEY_CHECKS = 0");
        }
        return Conexion::$conexion;
    }
    
    // Método para desconectar de la base de datos
    public static function desconectar() {
        return Conexion::$conexion = null;
    }
}
?>
