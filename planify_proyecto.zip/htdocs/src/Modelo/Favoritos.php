<?php 
namespace proyecto\Modelo;

use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;

class Favoritos {

    // Comprobar si el usuario existe
    private static function comprobarUsuarioExistente($usuario_id)
    {
        $conexion = Conexion::conectar();
        $query = "SELECT COUNT(*) FROM usuarios WHERE id = :usuario_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->execute();
        return $stmt->fetchColumn() > 0; // Devuelve true si existe, false si no
    }

    // Comprobar si la actividad existe
    private static function comprobarActividadExistente($actividad_id)
    {
        $conexion = Conexion::conectar();
        $query = "SELECT COUNT(*) FROM actividades WHERE id = :actividad_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':actividad_id', $actividad_id);
        $stmt->execute();
        return $stmt->fetchColumn() > 0; // Devuelve true si existe, false si no
    }

    // Comprobar si una actividad ya es favorita para un usuario
    private static function comprobarFavoritoExistente($usuario_id, $actividad_id)
    {
        $conexion = Conexion::conectar();
        $query = "SELECT COUNT(*) FROM favoritos WHERE usuario_id = :usuario_id AND actividad_id = :actividad_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->bindParam(':actividad_id', $actividad_id);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;  // Devuelve true si es favorito, false si no
    }

    // Agregar una actividad a los favoritos
    public static function agregarFavorito($usuario_id, $actividad_id)
    {
        // Comprobar si el usuario y la actividad existen y son favoritos
        if (!self::comprobarUsuarioExistente($usuario_id)||!self::comprobarActividadExistente($actividad_id)|| self::comprobarFavoritoExistente($usuario_id, $actividad_id)) {
            return false; 
        }

        // Si no es favorito, proceder a agregarlo
        $conexion = Conexion::conectar();
        $query = "INSERT INTO favoritos (usuario_id, actividad_id) VALUES (:usuario_id, :actividad_id)";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->bindParam(':actividad_id', $actividad_id);
        return $stmt->execute();  
    }

    // Eliminar una actividad de los favoritos
    public static function eliminarFavorito($usuario_id, $actividad_id)
    {
        // Comprobar si el usuario y la actividad existen
      // Comprobar si el usuario y la actividad existen y son favoritos
        if ( !self::comprobarFavoritoExistente($usuario_id, $actividad_id)) {
            return false; 
        }

        // Si es un favorito, proceder a eliminarlo
        $conexion = Conexion::conectar();
        $query = "DELETE FROM favoritos WHERE usuario_id = :usuario_id AND actividad_id = :actividad_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->bindParam(':actividad_id', $actividad_id);
        return $stmt->execute();  
    }

    // Comprueba si una actividad es favorita para un usuario
    public static function esFavorito($usuario_id, $actividad_id)
    {
        // Comprobar si el usuario y la actividad existen
        if (!self::comprobarUsuarioExistente($usuario_id) || !self::comprobarActividadExistente($actividad_id)) {
            return false; // Si no existe el usuario o la actividad, no puede ser favorito
        }

        return self::comprobarFavoritoExistente($usuario_id, $actividad_id);
    }
}
?>
