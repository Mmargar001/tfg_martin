<?php

namespace proyecto\Modelo;
use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;
class Notificaciones {

    // Agrega una nueva notificación
    public static function agregarNotificacion($usuario_id, $mensaje)
    {
        $conexion = Conexion::conectar();
        try {
            $stmt = $conexion->prepare("INSERT INTO notificaciones (usuario_id, mensaje, leida) VALUES (:usuario_id, :mensaje, 0)");
            $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
            $stmt->bindParam(':mensaje', $mensaje, PDO::PARAM_STR);
            return $stmt->execute(); // Retorna true si la inserción fue exitosa, false en caso contrario
        } catch (PDOException $e) {
            // Manejo de errores
            error_log("Error al agregar notificación: " . $e->getMessage());
            return false;
        }
    }

    // Obtiene notificaciones para un usuario
    public static function obtenerNotificaciones($usuario_id)
    {
        $conexion = Conexion::conectar();
        try {
            $stmt = $conexion->prepare("SELECT * FROM notificaciones WHERE usuario_id = :usuario_id AND leida = 0 ORDER BY fecha DESC");
            $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Manejo de errores
            error_log("Error al obtener notificaciones: " . $e->getMessage());
            return [];
        }
    }

    // Marca una notificación como leída
    public static function marcarComoLeida($notificacion_id)
    {
        $conexion = Conexion::conectar();
        try {
            $stmt = $conexion->prepare("UPDATE notificaciones SET leida = 1 WHERE id = :notificacion_id");
            $stmt->bindParam(':notificacion_id', $notificacion_id, PDO::PARAM_INT);
            return $stmt->execute(); // Retorna true si la actualización fue exitosa, false en caso contrario
        } catch (PDOException $e) {
            // Manejo de errores
            error_log("Error al marcar notificación como leída: " . $e->getMessage());
            return false;
        }
    }

    // Marca todas las notificaciones como leídas
    public static function marcarTodasComoLeidas($usuario_id)
    {
        $conexion = Conexion::conectar();
        try {
            $stmt = $conexion->prepare("UPDATE notificaciones SET leida = 1 WHERE usuario_id = :usuario_id");
            $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
            return $stmt->execute(); // Retorna true si la actualización fue exitosa, false en caso contrario
        } catch (PDOException $e) {
            // Manejo de errores
            error_log("Error al marcar todas las notificaciones como leídas: " . $e->getMessage());
            return false;
        }
    }

//Obtiene notif. no leidas
    public static function contarNoLeidas($usuario_id)
    {
        // Lógica para contar el número de notificaciones no leídas de un usuario
        $conexion = Conexion::conectar();
        $consulta = $conexion->prepare("SELECT COUNT(*) FROM notificaciones WHERE usuario_id = :usuario_id AND leida = 0");
        $consulta->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
        $consulta->execute();

        return $consulta->fetchColumn();
    }
    // Eliminar una notificación
    public static function eliminarNotificacion($notificacion_id)
    {
        $conexion = Conexion::conectar();
        try {
            $stmt = $conexion->prepare("DELETE FROM notificaciones WHERE id = :notificacion_id");
            $stmt->bindParam(':notificacion_id', $notificacion_id, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            // Manejo de errores
            error_log("Error al eliminar notificación: " . $e->getMessage());
            return false;
        }
    }

    // Obtener notificaciones filtradas por usuario y fecha
    public static function obtenerNotificacionesFiltradas($usuario_id = null, $fecha = null)
    {
        $conexion = Conexion::conectar();
        $query = "SELECT notificaciones.*, usuarios.nombre AS usuario_nombre FROM notificaciones JOIN usuarios ON notificaciones.usuario_id = usuarios.id WHERE 1=1";
        
        if ($usuario_id) {
            $query .= " AND notificaciones.usuario_id = :usuario_id";
        }
        if ($fecha) {
            $query .= " AND DATE(notificaciones.fecha) = :fecha";
        }

        $stmt = $conexion->prepare($query);

        if ($usuario_id) {
            $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
        }
        if ($fecha) {
            $stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
        }

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

