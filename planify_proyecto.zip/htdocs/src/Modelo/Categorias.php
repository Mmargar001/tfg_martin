<?php
namespace proyecto\Modelo;
use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;

class Categorias {
    
    // Comprobar si una categoría ya existe por su nombre
    private static function comprobarCategoriaExistente($id = null, $nombre = null) {
        $conexion = Conexion::conectar();
        
        // Si se pasa el ID, buscamos por ID
        if ($id) {
            $query = "SELECT COUNT(*) FROM categorias WHERE id = :id";
            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':id', $id);
        } 
        // Si no se pasa el ID, buscamos por nombre
        elseif ($nombre) {
            $query = "SELECT COUNT(*) FROM categorias WHERE nombre = :nombre";
            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':nombre', $nombre);
        } else {
            return false; // Si no se pasa ningún parámetro, no se puede verificar
        }

        $stmt->execute();
        return $stmt->fetchColumn() > 0;  // Devuelve true si existe la categoría, false si no
    }

    // Crear una nueva categoría
    public static function crearCategoria($nombre) {
        // Validaciones
        if (empty($nombre)) {
            return false; // Nombre vacío no es válido
        }

        // Comprobar si la categoría ya existe
        if (self::comprobarCategoriaExistente(null, $nombre)) {
            return false; // La categoría ya existe
        }

        // Si no existe, proceder con la creación
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("INSERT INTO categorias (Nombre) VALUES (:nombre)");
        $stmt->bindParam(':nombre', $nombre);
        return $stmt->execute();
    }

    // Obtener todas las categorías
    public static function obtenerCategorias() {
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("SELECT * FROM categorias");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Modificar una categoría existente
    public static function modificarCategoria($id, $nombre) {
        // Validaciones
        if (empty($nombre)) {
            return false; // Nombre vacío no es válido
        }

        // Comprobar si la categoría con el ID existe
        if (!self::comprobarCategoriaExistente($id)) {
            return false; // La categoría no existe
        }

  

        // Procedemos a modificar la categoría
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("UPDATE categorias SET nombre = :nombre WHERE id = :id");
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    // Eliminar una categoría por ID
    public static function eliminarCategoria($id) {
        // Comprobar si la categoría con el ID existe
        if (!self::comprobarCategoriaExistente($id)) {
            return false; // La categoría no existe
        }

        // Procedemos a eliminar la categoría
        $conexion = Conexion::conectar();
        $stmt = $conexion->prepare("DELETE FROM categorias WHERE id = :id");
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
   
}
?>
