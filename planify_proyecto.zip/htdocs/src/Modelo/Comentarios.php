<?php
namespace proyecto\Modelo;
use proyecto\Modelo\Conexion; // Usamos la clase Conexion desde el namespace correcto
use PDO;

class Comentarios {

    // Verificar si el usuario existe
    private static function comprobarUsuarioExistente($usuario_id) {
        $conexion = Conexion::conectar();
        $query = "SELECT COUNT(*) FROM usuarios WHERE id = :usuario_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;  // Devuelve true si el usuario existe
    }

    // Verificar si la actividad existe
    private static function comprobarActividadExistente($actividad_id) {
        $conexion = Conexion::conectar();
        $query = "SELECT COUNT(*) FROM actividades WHERE id = :actividad_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':actividad_id', $actividad_id);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;  // Devuelve true si la actividad existe
    }

    // Crea un nuevo comentario en la base de datos.
    public static function crearComentario($usuario_id, $actividad_id, $comentario, $puntuacion) {
        // Verificar si el usuario y la actividad existen
        if (!self::comprobarUsuarioExistente($usuario_id) || !self::comprobarActividadExistente($actividad_id)) {
            return false;  // Si el usuario o la actividad no existen, no se puede crear el comentario
        }

        $conexion = Conexion::conectar();
        $query = "INSERT INTO comentarios (usuario_id, actividad_id, comentario, puntuacion, fecha)
                  VALUES (:usuario_id, :actividad_id, :comentario, :puntuacion, NOW())";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->bindParam(':actividad_id', $actividad_id);
        $stmt->bindParam(':comentario', $comentario);
        $stmt->bindParam(':puntuacion', $puntuacion);
        return $stmt->execute();
    }

    // Elimina un comentario de la base de datos.
    public static function eliminarComentario($comentario_id) {
        // Verificar si el comentario existe
        $comentario = self::obtenerComentarioPorId($comentario_id);
        if (!$comentario) {
            return false;  // Si el comentario no existe, no se puede eliminar
        }

        $conexion = Conexion::conectar();
        $query = "DELETE FROM comentarios WHERE id = :comentario_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':comentario_id', $comentario_id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    // Obtiene todos los comentarios asociados a una actividad específica.
    public static function obtenerComentariosPorActividad($actividad_id) {
        // Verificar si la actividad existe
        if (!self::comprobarActividadExistente($actividad_id)) {
            return [];  // Si la actividad no existe, no hay comentarios que devolver
        }

        $conexion = Conexion::conectar();
        $query = "SELECT c.*, u.nombre AS usuario FROM comentarios c
                  JOIN usuarios u ON c.usuario_id = u.id
                  WHERE c.actividad_id = :actividad_id
                  ORDER BY c.fecha DESC";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':actividad_id', $actividad_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtiene la puntuación promedio de una actividad basada en los comentarios.
    public static function obtenerPuntuacionPromedio($actividad_id) {
        // Verificar si la actividad existe
        if (!self::comprobarActividadExistente($actividad_id)) {
            return 0;  // Si la actividad no existe, no hay puntuaciones
        }

        $conexion = Conexion::conectar();
        $query = "SELECT AVG(puntuacion) AS promedio FROM comentarios WHERE actividad_id = :actividad_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':actividad_id', $actividad_id);
        $stmt->execute();
        return round($stmt->fetchColumn(), 1); // Redondea a un decimal
    }

    // Obtiene un comentario específico por su ID.
    public static function obtenerComentarioPorId($comentario_id) {
        $conexion = Conexion::conectar();
        $query = "SELECT * FROM comentarios WHERE id = :comentario_id";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':comentario_id', $comentario_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>
