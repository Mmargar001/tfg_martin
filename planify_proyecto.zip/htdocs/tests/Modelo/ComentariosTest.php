<?php

use PHPUnit\Framework\TestCase;
use proyecto\Modelo\Comentarios;
use proyecto\Modelo\Conexion;

class ComentariosTest extends TestCase {

// Crear una conexión de prueba con la base de datos
    protected static $conexion;

// Establecer conexión antes de ejecutar los tests
    public static function setUpBeforeClass(): void
    {
        self::$conexion = Conexion::conectar();
    }

// Test para crear un comentario correctamente
    public function testCrearComentario()
    {
        $usuario_id = 5;
        $actividad_id = 1;
        $comentario = "Este es un comentario de prueba";
        $puntuacion = 5;

// Crear el comentario
        $resultado = Comentarios::crearComentario($usuario_id, $actividad_id, $comentario, $puntuacion);

// Verificar que el comentario fue creado correctamente
        $this->assertTrue($resultado);
    }

// Test para intentar crear un comentario con un usuario y actividad inexistentes
    public function testCrearComentarioConUsuarioInexistente()
    {
        $usuario_id = 999;  // ID de usuario no existente
        $actividad_id = 100;
        $comentario = "Este es un comentario de prueba";
        $puntuacion = 5;

// Intentar crear un comentario con un usuario que no existe
        $resultado = Comentarios::crearComentario($usuario_id, $actividad_id, $comentario, $puntuacion);

// Verificar que no se puede crear el comentario
        $this->assertFalse($resultado);
    }

// Test para eliminar un comentario correctamente
//    public function testEliminarComentario()
//    {
//// Asumir que existe un comentario con ID 1
//        $comentario_id = 1;
//
//// Eliminar el comentario
//        $resultado = Comentarios::eliminarComentario($comentario_id);
//
//// Verificar que el comentario fue eliminado
//        $this->assertTrue($resultado);
//    }

// Test para intentar eliminar un comentario que no existe
    public function testEliminarComentarioNoExistente()
    {
        $comentario_id = 999;  // ID de comentario no existente
// Intentar eliminar el comentario que no existe
        $resultado = Comentarios::eliminarComentario($comentario_id);

// Verificar que no se puede eliminar el comentario
        $this->assertFalse($resultado);
    }

    
// Test para obtener los comentarios de una actividad
    public function testObtenerComentariosPorActividad()
    {
// Definir una actividad de prueba que tenga comentarios
        $actividad_id = 1;

// Obtener los comentarios asociados a esta actividad
        $comentarios = Comentarios::obtenerComentariosPorActividad($actividad_id);

// Verificar que se ha devuelto un arreglo
        $this->assertIsArray($comentarios);

// Verificar que los comentarios corresponden a la actividad y tienen datos
        if (count($comentarios) > 0)
        {
            $this->assertArrayHasKey('usuario', $comentarios[0]);  // Verifica que el nombre del usuario está presente
            $this->assertArrayHasKey('comentario', $comentarios[0]);  // Verifica que el comentario está presente
        }
    }

// Test para obtener los comentarios de una actividad que no existe
    public function testObtenerComentariosPorActividadNoExistente()
    {
// Actividad que no existe
        $actividad_id = 999;

// Obtener los comentarios asociados a esta actividad
        $comentarios = Comentarios::obtenerComentariosPorActividad($actividad_id);

// Verificar que se devuelve un arreglo vacío
        $this->assertEmpty($comentarios);
    }

// Test para obtener la puntuación promedio de una actividad
    public function testObtenerPuntuacionPromedio()
    {
// Definir una actividad de prueba con comentarios
        $actividad_id = 1;

// Obtener la puntuación promedio de la actividad
        $puntuacionPromedio = Comentarios::obtenerPuntuacionPromedio($actividad_id);

// Verificar que la puntuación promedio es un número
        $this->assertIsFloat($puntuacionPromedio);
        $this->assertGreaterThanOrEqual(0, $puntuacionPromedio);  // Asegurarse de que la puntuación es positiva o cero
    }

// Test para obtener la puntuación promedio de una actividad que no tiene comentarios
    public function testObtenerPuntuacionPromedioActividadSinComentarios()
    {
// Actividad sin comentarios
        $actividad_id = 999;

// Obtener la puntuación promedio de la actividad
        $puntuacionPromedio = Comentarios::obtenerPuntuacionPromedio($actividad_id);

// Verificar que la puntuación promedio es 0
        $this->assertEquals(0, $puntuacionPromedio);
    }

// Test para obtener un comentario específico por su ID
    public function testObtenerComentarioPorId()
    {
// Definir un comentario que existe en la base de datos
        $comentario_id = 2;

// Obtener el comentario por su ID
        $comentario = Comentarios::obtenerComentarioPorId($comentario_id);

// Verificar que el comentario ha sido encontrado
        $this->assertNotNull($comentario);
        $this->assertArrayHasKey('comentario', $comentario);  // Verifica que el campo 'comentario' está presente
    }

// Test para intentar obtener un comentario que no existe
    public function testObtenerComentarioPorIdNoExistente()
    {
// Comentario que no existe
        $comentario_id = 999;

// Intentar obtener el comentario por su ID
        $comentario = Comentarios::obtenerComentarioPorId($comentario_id);

// Verificar que no se ha encontrado el comentario
         $this->assertFalse($comentario);
    }
}

?>
