<?php

use proyecto\Modelo\Usuarios;
use PHPUnit\Framework\TestCase;

class UsuariosTest extends TestCase
{

    public function testCrearUsuario()
    {
            // Caso 1: Crear un usuario válido
        $nombre = 'Carlos';
        $clave = 'contraseña_segura';
        $tipo_usuario = 'cliente';
        $resultado = Usuarios::crearUsuario($nombre, $clave, $tipo_usuario);
        $this->assertTrue($resultado);  // El usuario debería crearse correctamente

        // Caso 2: Intentar crear un usuario con un nombre vacío
        $nombre = '';
        $clave = 'contraseña_segura';
        $tipo_usuario = 'cliente';
        $resultado = Usuarios::crearUsuario($nombre, $clave, $tipo_usuario);
        $this->assertFalse($resultado);  // Debería devolver false si los parámetros son incorrectos
    }

 

   
    public function testObtenerUsuarios()
    {

        $usuarios = Usuarios::obtenerUsuarios();
        $this->assertIsArray($usuarios);  // Debe ser un array
        $this->assertGreaterThan(0, count($usuarios));  // Debe haber al menos un usuario

      }

   
    public function testObtenerUsuarioPorNombre()
    {
         // Caso 1: Obtener un usuario existente por nombre
        $nombre = 'Carlos';  // Suponiendo que "Juan" existe en la base de datos
        $usuario = Usuarios::obtenerUsuarioPorNombre($nombre);
        $this->assertNotNull($usuario);  // Debería devolver un usuario válido
        $this->assertEquals($nombre, $usuario['nombre']);  // El nombre debe coincidir con el solicitado

        // Caso 2: Intentar obtener un usuario que no existe
        $nombre = 'NoExistente';  // Nombre que no existe en la base de datos
        $usuario = Usuarios::obtenerUsuarioPorNombre($nombre);
        $this->assertNull($usuario);  // No debería devolver ningún usuario
    }


    public function testActualizarUsuario()
    {
            // Caso 1: Actualizar un usuario existente
        $id = 8;  // Suponiendo que el usuario con ID 5 existe
        $nuevo_nombre = 'Antonio';
        $nuevo_email = 'antonio@mail.com';
        $nuevo_telefono = '657915800';
        $resultado = Usuarios::actualizarUsuario($id, $nuevo_nombre, $nuevo_email, $nuevo_telefono);
        $this->assertTrue($resultado);  // Los detalles del usuario deben ser actualizados correctamente

        // Caso 2: Intentar actualizar un usuario con un ID inexistente
        $id = 9999;  // ID que no existe
        $nuevo_nombre = 'NoExiste';
        $nuevo_email = 'noexiste@mail.com';
        $nuevo_telefono = '000000000';
        $resultado = Usuarios::actualizarUsuario($id, $nuevo_nombre, $nuevo_email, $nuevo_telefono);
        $this->assertFalse($resultado);  // No debería actualizarse y debe devolver false
    }


    public function testActualizarContrasena()
    {
            // Caso 1: Actualizar la contraseña de un usuario existente
        $usuario_id = 8;  // Suponiendo que el usuario con ID 5 existe
        $nueva_contrasena = 'nueva_contrasena_segura';
        $resultado = Usuarios::actualizarContrasena($usuario_id, $nueva_contrasena);
        $this->assertTrue($resultado);  // La contraseña debe ser actualizada correctamente

        // Caso 2: Intentar actualizar la contraseña de un usuario inexistente
        $usuario_id = 9999;  // ID que no existe
        $nueva_contrasena = 'nueva_contrasena_segura';
        $resultado = Usuarios::actualizarContrasena($usuario_id, $nueva_contrasena);
        $this->assertFalse($resultado);  // No debería actualizarse y debe devolver false
    }
 
    public function testEliminarUsuario()
    {
              // Caso 1: Eliminar un usuario existente
        $id = 8;  // Suponiendo que el usuario con ID 21 existe
        $resultado = Usuarios::eliminarUsuario($id);
        $this->assertTrue($resultado);  // El usuario debería eliminarse correctamente

        // Caso 2: Intentar eliminar un usuario que no existe
        $id = 9999;  // ID que no existe
        $resultado = Usuarios::eliminarUsuario($id);
        $this->assertFalse($resultado);  // No debería eliminarse y debería devolver false
    }
}

?>
