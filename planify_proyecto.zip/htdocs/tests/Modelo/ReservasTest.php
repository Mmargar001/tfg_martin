<?php

use PHPUnit\Framework\TestCase;
use proyecto\Modelo\Reservas;
use proyecto\Modelo\Conexion;

class ReservasTest extends TestCase
{
    protected static $conexion;

    public static function setUpBeforeClass(): void
    {
        self::$conexion = Conexion::conectar();
    }

    public function testCrearReserva()
    {
        // Caso 1: Crear una reserva con datos válidos
        $itinerario_id = 20;
        $usuario_id = 7;
        $monto = 100.50;

        $resultado = Reservas::crearReserva($itinerario_id, $usuario_id, $monto);
        $this->assertIsNumeric($resultado);

        // Caso 2: Crear una reserva con itinerario_id nulo
        $itinerario_id = null;
        $resultado = Reservas::crearReserva($itinerario_id, $usuario_id, $monto);
        $this->assertFalse($resultado);
    }

    public function testObtenerReservasPorUsuario()
    {
        // Crear una reserva para garantizar datos
        Reservas::crearReserva(20, 7, 50.00);

        // Caso 3: Obtener reservas de un usuario que tiene reservas
        $usuario_id = 7;
        $reservas = Reservas::obtenerReservasPorUsuario($usuario_id);
        $this->assertIsArray($reservas);
        $this->assertNotEmpty($reservas);

        // Caso 4: Obtener reservas de un usuario inexistente
        $usuario_id = 9999;
        $reservas = Reservas::obtenerReservasPorUsuario($usuario_id);
        $this->assertIsArray($reservas);
        $this->assertEmpty($reservas);
    }

    public function testObtenerReservaPorId()
    {
        // Crear una reserva para usar su ID
        $reserva_id = Reservas::crearReserva(20, 7, 150.00);

        // Caso 5: Obtener una reserva existente por su ID
        $reserva = Reservas::obtenerReservaPorId($reserva_id);
        $this->assertNotNull($reserva);
        $this->assertArrayHasKey('id', $reserva);
        $this->assertArrayHasKey('monto', $reserva);

        // Caso 6: Obtener una reserva inexistente por su ID
        $reserva = Reservas::obtenerReservaPorId(9999);
        $this->assertNull($reserva);
    }

    public function testActualizarEstado()
    {

        // Caso 7: Actualizar el estado de una reserva con un estado válido
        $nuevoEstado = 'confirmada';
        $resultado = Reservas::actualizarEstado(21, $nuevoEstado);
        $this->assertTrue($resultado);

        // Caso 8: Actualizar el estado de una reserva con un estado inválido
        $nuevoEstado = 'inexistente';
        $resultado = Reservas::actualizarEstado(21, $nuevoEstado);
        $this->assertFalse($resultado);
    }

    public function testCancelarReserva()
    {

        // Caso 9: Cancelar una reserva existente
        $resultado = Reservas::cancelarReserva(21);
        $this->assertTrue($resultado);

        // Caso 10: Cancelar una reserva inexistente
        $resultado = Reservas::cancelarReserva(9999);
        $this->assertFalse($resultado);
    }
    public function testActualizarPresupuesto()
{
    // Caso 1: Actualizar presupuesto de un itinerario existente
    $itinerario_id = 20; // Itinerario válido
    $monto = 50.00;
    $resultado = Reservas::actualizarPresupuesto($itinerario_id, $monto);
    $this->assertTrue($resultado); // Se debe actualizar correctamente

    // Caso 2: Intentar actualizar un itinerario inexistente
    $itinerario_id = 9999; // Itinerario no existente
    $monto = 30.00;
    $resultado = Reservas::actualizarPresupuesto($itinerario_id, $monto);
    $this->assertFalse($resultado); // Debe devolver false
}

public function testObtenerCosteTotalActividades()
{
    // Caso 1: Itinerario con actividades
    $itinerario_id = 20;
    // Supongamos que en la BD ya hay actividades asociadas con precios
    $total = Reservas::obtenerCosteTotalActividades($itinerario_id);
    $this->assertIsFloat($total);
    $this->assertGreaterThan(0, $total); // Debe ser mayor a 0

    // Caso 2: Itinerario sin actividades
    $itinerario_id = 9999; // Un itinerario que no tiene actividades
    $total = Reservas::obtenerCosteTotalActividades($itinerario_id);
    $this->assertEquals(0, $total); // Debe ser 0
}



    public function testObtenerPresupuesto()
{
    // Caso 1: Obtener presupuesto de un itinerario existente
    $itinerario_id = 20; // Itinerario válido
    $presupuesto = Reservas::obtenerPresupuesto($itinerario_id);
    $this->assertIsFloat($presupuesto);
    $this->assertGreaterThanOrEqual(0, $presupuesto); // El presupuesto debe ser >= 0

    // Caso 2: Intentar obtener presupuesto de un itinerario inexistente
    $itinerario_id = 9999; // Itinerario no existente
    $presupuesto = Reservas::obtenerPresupuesto($itinerario_id);
    $this->assertEquals(0, $presupuesto); // Debe devolver 0
}
public function testEliminarReserva()
{
    // Caso 1: Eliminar una reserva existente
    $reserva_id = 19;
    $resultado = Reservas::eliminarReserva($reserva_id);
    $this->assertTrue($resultado); // Se debe eliminar correctamente

    // Caso 2: Intentar eliminar una reserva inexistente
    $resultado = Reservas::eliminarReserva(9999); // ID inexistente
    $this->assertFalse($resultado); // Debe devolver false o no eliminar
}


}
?>
