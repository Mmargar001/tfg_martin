<?php

use PHPUnit\Framework\TestCase;
use proyecto\Modelo\Actividades;
use proyecto\Modelo\Conexion;

class ActividadesTest extends \PHPUnit\Framework\TestCase
{
    // Conexión a la base de datos en memoria antes de cada prueba
    public function setUp(): void
    {
     
        
        // Crear la tabla actividades para pruebas
        $conexion = Conexion::conectar();
    
    }



    // Crear una actividad correctamente
    public function testCrearActividad()
    {
        $resultado = Actividades::crearActividad("Spinning", "Clase activa", 2, "Sala A", 20, "Bienestar", "2024-12-10", "10:00");
        $this->assertTrue($resultado); // Se espera que la actividad sea creada con éxito
    }

    // Intentar crear actividad con datos inválidos
    public function testCrearActividadConDatosInvalidos()
    {
        $resultado = Actividades::crearActividad("", "", -1, "", -5, "", "2024-12-10", "10:00");
        $this->assertFalse($resultado);  // Se espera que falle debido a los datos no válidos
    }

    // Editar una actividad existente
    public function testEditarActividad()
    {
      
        // Editar la actividad
        $resultado = Actividades::editarActividad(30, "Clase de Natación", "Clase más intensa", 2, "Sala B", 25, "Bienestar", "2024-12-10", "12:00");
        $this->assertTrue($resultado); // Se espera que la edición sea exitosa
    }

    // Intentar editar una actividad inexistente
    public function testEditarActividadInexistente()
    {
        $resultado = Actividades::editarActividad(999, "Clase de Yoga", "Clase relajante", 2, "Sala A", 20, "Bienestar", "2024-12-10", "10:00");
        $this->assertFalse($resultado); // Se espera que falle, no existe la actividad con ID 999
    }

    // Eliminar una actividad existente
    public function testEliminarActividad()
    {
        // Crear una actividad
        

        // Eliminar la actividad
        $resultado = Actividades::eliminarActividad(31);
        $this->assertTrue($resultado); // Se espera que la actividad sea eliminada correctamente
    }

    // Intentar eliminar una actividad inexistente
    public function testEliminarActividadInexistente()
    {
        $resultado = Actividades::eliminarActividad(999);
        $this->assertFalse($resultado); // Se espera que falle, no existe la actividad con ID 999
    }

    // Obtener todas las actividades
    public function testObtenerActividades()
    {
      

        $actividades = Actividades::obtenerActividades();

        // Verifica que se devuelvan exactamente dos actividades
        $this->assertCount(11, $actividades);
    }

    // Obtener actividad por ID
    public function testObtenerActividadPorId()
    {
      

        
        $actividad = Actividades::obtenerActividadPorId(30);

        // Verifica que la actividad devuelta tenga el id 1
        $this->assertNotFalse($actividad); // Se espera que no devuelva false
        $this->assertEquals(30, $actividad['id']); // Se espera que devuelva la actividad con ID 1
    }



}

?>
