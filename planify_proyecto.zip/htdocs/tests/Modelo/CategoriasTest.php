<?php

use PHPUnit\Framework\TestCase;
use proyecto\Modelo\Categorias;
use proyecto\Modelo\Conexion;

class CategoriasTest extends TestCase {

    // Crear una conexión de prueba con la base de datos
    protected static $conexion;

    // Establecer conexión antes de ejecutar los tests
    public static function setUpBeforeClass(): void
    {
        self::$conexion = Conexion::conectar();
    }



    // Test para la creación de una categoría
    public function testCrearCategoria()
    {
        // Crear la categoría
        $resultado = Categorias::crearCategoria('test4');

        // Verificar que la categoría se haya creado correctamente
        $this->assertTrue($resultado);
    }

    // Test para intentar crear una categoría con un nombre duplicado
    public function testCrearCategoriaDuplicada()
    {

        // Intentar crear la misma categoría de nuevo
        $resultado = Categorias::crearCategoria('test3');

        // Verificar que no se puede crear la categoría duplicada
        $this->assertFalse($resultado);
    }

    // Test para modificar una categoría existente
    public function testModificarCategoria()
    {

       // Modificar la categoría
       $resultado = Categorias::modificarCategoria(35, 'Prueba categoria');

       // Verificar que la modificación fue exitosa
       $this->assertTrue($resultado);
   }

    // Test para intentar modificar una categoría que no existe
    public function testModificarCategoriaNoExistente()
    {
        $resultado = Categorias::modificarCategoria(999, 'CategoriaInexistente');

        // Verificar que no se puede modificar una categoría inexistente
        $this->assertFalse($resultado);
    }
    
// Test para eliminar una categoría existente
   public function testEliminarCategoria()
   {
       // Eliminar la categoría
       $resultado = Categorias::eliminarCategoria(37);

        // Verificar que la categoría fue eliminada correctamente
       $this->assertTrue($resultado);
    }

    // Test para intentar eliminar una categoría que no existe
    public function testEliminarCategoriaNoExistente()
    {
        $resultado = Categorias::eliminarCategoria(999);  // ID no existente
        // Verificar que no se puede eliminar una categoría inexistente
        $this->assertFalse($resultado);
    }
     // Obtener todas las categorias
    public function testObtenerCategoria()
    {
        $resultado = Categorias::obtenerCategorias();

        // Verifica que se devuelvan exactamente dos actividades
        $this->assertCount(8, $resultado);
    }
}

?>
