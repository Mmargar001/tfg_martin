<?php

use PHPUnit\Framework\TestCase;
use proyecto\Modelo\Favoritos;
use proyecto\Modelo\Conexion;

class FavoritosTest extends TestCase {

    // Crear una conexión de prueba con la base de datos
    protected static $conexion;

    // Establecer conexión antes de ejecutar los tests
    public static function setUpBeforeClass(): void
    {
        self::$conexion = Conexion::conectar();
    }

    // Test para agregar un favorito correctamente
    public function testAgregarFavorito()
    {

        // Agregar a favoritos
        $resultado = Favoritos::agregarFavorito(5, 1);

        // Verificar que se ha agregado correctamente
        $this->assertTrue($resultado);
    }

    // Test para intentar agregar un favorito que ya existe
    public function testAgregarFavoritoExistente()
    {

        // Intentar agregar el mismo favorito de nuevo
        $resultado = Favoritos::agregarFavorito(5, 1);

        // Verificar que no se ha agregado porque ya existe
        $this->assertFalse($resultado);
    }

    // Test para intentar agregar un favorito con un usuario inexistente
    public function testAgregarFavoritoConUsuarioActividadInexistente()
    {

        // Intentar agregar un favorito con un usuario que no existe
        $resultado = Favoritos::agregarFavorito(999, 100);

        // Verificar que no se puede agregar el favorito porque el usuario no existe
        $this->assertFalse($resultado);
    }

    // Test para eliminar un favorito correctamente
    public function testEliminarFavorito()
    {

        // Agregar a favoritos
        Favoritos::agregarFavorito(5, 2);

        // Eliminar el favorito
        $resultado = Favoritos::eliminarFavorito(5, 2);

        // Verificar que el favorito fue eliminado
        $this->assertTrue($resultado);
    
    }

    // Test para intentar eliminar un favorito que no existe
    public function testEliminarFavoritoNoExistente()
    {

        // Intentar eliminar un favorito que no existe
        $resultado = Favoritos::eliminarFavorito(1, 100);

        // Verificar que no se puede eliminar un favorito que no existe
        $this->assertFalse($resultado);
    }

    // Test para comprobar si una actividad es favorita
    public function testEsFavorito()
    {

        // Verificar que ahora es favorito
        $this->assertTrue(Favoritos::esFavorito(5, 1));
    }

    // Test para comprobar que no se puede agregar un favorito sin usuario ni actividad
    public function testAgregarFavoritoSinDatos()
    {
        // Intentar agregar sin usuario ni actividad (debería fallar)
        $resultado = Favoritos::agregarFavorito(null, null);

        // Verificar que la operación no fue exitosa
        $this->assertFalse($resultado);
    }
}
?>
