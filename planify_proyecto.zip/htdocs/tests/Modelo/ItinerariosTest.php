<?php

use PHPUnit\Framework\TestCase;
use proyecto\Modelo\Itinerarios;

class ItinerariosTest extends TestCase
{
    public function testCrearOActualizarItinerario()
    {
        // Caso 1: Crear un itinerario nuevo
        $usuarioId = 7;
        $nombre = 'Vacaciones';
        $descripcion = 'Viaje a la playa';
        $presupuesto = 1000;
        $resultado = Itinerarios::crearOActualizarItinerario($usuarioId, $nombre, $descripcion, $presupuesto);
        $this->assertTrue($resultado);

        // Caso 2: Actualizar un itinerario existente
        $descripcion = 'Viaje al Caribe';
        $presupuesto = 2000;
        $resultado = Itinerarios::crearOActualizarItinerario($usuarioId, $nombre, $descripcion, $presupuesto);
        $this->assertTrue($resultado);

        // Caso 3: Intentar crear con datos incompletos
        $usuarioId = null;
        $resultado = Itinerarios::crearOActualizarItinerario($usuarioId, 'Aventura', 'Excursión', $presupuesto);
        $this->assertFalse($resultado);
    }


    public function testObtenerItinerarioPorId()
    {
        $itinerarioId = 21;
        $resultado = Itinerarios::obtenerItinerarioPorId($itinerarioId);
        $this->assertIsArray($resultado);
        $this->assertArrayHasKey('id', $resultado);
    }

    public function testObtenerActividadesPorItinerario()
    {
        $itinerarioId = 21;
        $resultado = Itinerarios::obtenerActividadesPorItinerario($itinerarioId);
        $this->assertIsArray($resultado);
    }

    public function testAgregarActividad()
    {
        $itinerarioId = 21;
        $actividadId = 5;
        $resultado = Itinerarios::agregarActividad($itinerarioId, $actividadId);
        $this->assertTrue($resultado);
    }

    public function testEliminarActividad()
    {
        $itinerarioId = 21;
        $actividadId = 5;
        $resultado = Itinerarios::eliminarActividad($itinerarioId, $actividadId);
        $this->assertTrue($resultado);
    }


    public function testContarActividades()
    {
        $itinerarioId = 21;
        $resultado = Itinerarios::contarActividades($itinerarioId);
        $this->assertIsInt($resultado);
        $this->assertGreaterThanOrEqual(0, $resultado);
    }

    public function testObtenerItinerariosFiltrados()
    {
        $usuarioId = 7;
        $fechaCreacion = '2024-09-09';
        $resultado = Itinerarios::obtenerItinerariosFiltrados($usuarioId, $fechaCreacion);
        $this->assertIsArray($resultado);
    }
        public function testEliminarItinerario()
    {
        $itinerarioId = 21;
        $resultado = Itinerarios::eliminarItinerario($itinerarioId);
        $this->assertTrue($resultado);

        $itinerarioId = 9999;
        $resultado = Itinerarios::eliminarItinerario($itinerarioId);
        $this->assertFalse($resultado);
    }

}
