<?php

use PHPUnit\Framework\TestCase;
use proyecto\Modelo\Notificaciones;
use proyecto\Modelo\Conexion;

class NotificacionesTest extends TestCase {

    // Crear una conexión de prueba con la base de datos
    protected static $conexion;

    // Establecer conexión antes de ejecutar los tests
    public static function setUpBeforeClass(): void
    {
        self::$conexion = Conexion::conectar();
    }

    // Test para agregar una notificación
    public function testAgregarNotificacion()
    {
        $usuario_id = 5;
        $mensaje = "Prueba de notificación";

        $resultado = Notificaciones::agregarNotificacion($usuario_id, $mensaje);

        $this->assertTrue($resultado); // Verificar que la inserción fue exitosa
    }

    // Test para obtener notificaciones no leídas
    public function testObtenerNotificaciones()
    {
        $usuario_id = 5;

        $notificaciones = Notificaciones::obtenerNotificaciones($usuario_id);

        $this->assertIsArray($notificaciones); // Verificar que se devuelve un arreglo

        if (!empty($notificaciones)) {
            $this->assertArrayHasKey('mensaje', $notificaciones[0]); // Verificar que los mensajes están presentes
            $this->assertEquals(0, $notificaciones[0]['leida']); // Verificar que no están leídas
        }
    }

    // Test para marcar una notificación como leída
    public function testMarcarComoLeida()
    {
        $notificacion_id = 1; // Asume que esta notificación existe en la base de datos

        $resultado = Notificaciones::marcarComoLeida($notificacion_id);

        $this->assertTrue($resultado); // Verificar que la operación fue exitosa
    }

    // Test para marcar todas las notificaciones como leídas
    public function testMarcarTodasComoLeidas()
    {
        $usuario_id = 5;

        $resultado = Notificaciones::marcarTodasComoLeidas($usuario_id);

        $this->assertTrue($resultado); // Verificar que todas las notificaciones fueron marcadas como leídas
    }

    // Test para contar las notificaciones no leídas
    public function testContarNoLeidas()
    {
       $usuario_id = 5;

        $conteo = Notificaciones::contarNoLeidas($usuario_id);

        $this->assertIsInt($conteo); // Verificar que se devuelve un número entero
        $this->assertGreaterThanOrEqual(0, $conteo); // Asegurarse de que el conteo es positivo
    }

    // Test para eliminar una notificación
    public function testEliminarNotificacion()
    {
        $notificacion_id = 1; // Asume que esta notificación existe en la base de datos

        $resultado = Notificaciones::eliminarNotificacion($notificacion_id);

        $this->assertTrue($resultado); // Verificar que la notificación fue eliminada
    }

    // Test para obtener notificaciones filtradas
    public function testObtenerNotificacionesFiltradas()
    {
        $usuario_id = 5;
        $fecha = date('Y-m-d'); // Usar la fecha actual para el filtro

        $notificaciones = Notificaciones::obtenerNotificacionesFiltradas($usuario_id, $fecha);

        $this->assertIsArray($notificaciones); // Verificar que se devuelve un arreglo

        if (!empty($notificaciones)) {
            $this->assertArrayHasKey('usuario_nombre', $notificaciones[0]); // Verificar que el nombre del usuario está presente
            $this->assertArrayHasKey('mensaje', $notificaciones[0]); // Verificar que el mensaje está presente
        }
    }

    // Test para obtener notificaciones filtradas sin parámetros
    public function testObtenerNotificacionesFiltradasSinParametros()
    {
        $notificaciones = Notificaciones::obtenerNotificacionesFiltradas();

        $this->assertIsArray($notificaciones); // Verificar que se devuelve un arreglo

        if (!empty($notificaciones)) {
            $this->assertArrayHasKey('usuario_nombre', $notificaciones[0]); // Verificar que el nombre del usuario está presente
            $this->assertArrayHasKey('mensaje', $notificaciones[0]); // Verificar que el mensaje está presente
        }
    }
}
?>
